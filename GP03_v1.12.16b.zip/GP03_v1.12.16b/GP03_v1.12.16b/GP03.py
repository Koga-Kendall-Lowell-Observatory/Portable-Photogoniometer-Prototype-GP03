# python complains about this import, but it works
from PyQt5 import QtCore, QtGui, QtWidgets
import goniometer
from colorama import Fore
import tkinter
from tkinter import filedialog
import os
from os.path import exists

# Goniometer GP03 GUI
# Code Version: v0.6.0a
# Institution: Lowell Observatory
# Developer: Kendall Koga
# Date: 03/2/2023

# CONFIGURE GP03
########################################################################################################################
# Data Folder Directory ################################################################################################
data_folder_directory = '<Data Folder Directory>'
########################################################################################################################
# fast mode toggle, this switches between fast mode and precision mode
goniometer.fast_mode = True
# recommend 10
captures = 10
# reference reflectance value for reflectance equation
reference_reflectance = 1
# name of reference material
reference_material = '<Material Name>'
# name of material used for SNR measurements
snr_material = '<Material Name>'
# recommend is 100
snr_stack_number = 100
# latitude size degrees >= 2.5 degrees
latitude_size_degrees = '<Latitudinal Size in Degrees Corresponding to the Aperture in Use>'
# spot size >= 6.5 mm
spot_size_mm = '<Size of the Aperture in Use>'
# recommend 5
azimuth_width_px = 5
# arduino bit value corresponding to the zenith
zenith_led_bit = '<LED Bit Value Corresponding to the Zenith for Arduino in Use>'
# Light Source Angles of Incidence
incidence_angles = [0, 15, 30, 45, 60, 75]
# Available/Desired Azimuths
azimuths = [0, 30, 60, 90, 120, 150, 180]
# Available/Desired Lines by Their Letter Names
lines = ["A", "B", "C", "D", "E", "F", "G"]
# Reflectance Mode
reflectance_mode = "REFF"


def get_reflectance():
    # check that data directory in goniometer library is set correctly
    try:
        if data_folder_directory is not None:
            pass
        else:
            raise TypeError
    except TypeError:
        print(Fore.RED + "TypeError: Missing Data Folder Directory")
        exit()

    try:
        if goniometer.data_folder_directory is not None:
            pass
        else:
            raise TypeError
    except TypeError:
        print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
        exit()

    average_flux_data_input_directory = data_folder_directory + '/temp/flux_data'
    average_flux_data_output_directory = data_folder_directory + '/temp/averaged_data/flux'
    average_reference_data_input_directory = data_folder_directory + '/reference_library/' + reference_material + '_' \
        + str(captures) + '_width_' + str(azimuth_width_px)
    average_reference_data_output_directory = data_folder_directory + '/temp/averaged_data/reference'
    snr_directory = data_folder_directory + '/snr_library/' + str(snr_material) + '_snr_' + str(captures) + '_' \
        + str(snr_stack_number)

    # gather flux data
    goniometer.get_data(captures, azimuth_width_px, incidence_angles)

    # average flux data
    print('Processing Flux:')
    goniometer.average_data(average_flux_data_input_directory, average_flux_data_output_directory, snr_directory,
                            latitude_size_degrees, azimuth_width_px, incidence_angles, azimuths, lines)
    # average reference data
    print('Processing Reference Flux:')
    goniometer.average_data(average_reference_data_input_directory, average_reference_data_output_directory,
                            snr_directory, latitude_size_degrees, azimuth_width_px, incidence_angles,
                            azimuths, lines)

    # prompt user for a directory, if a directory that does not exist is typed into the dialog box, it will create it
    reflectance_destination_directory = None
    while reflectance_destination_directory is None or reflectance_destination_directory == str('()'):
        tkinter.Tk().withdraw()
        reflectance_destination_directory = filedialog.askdirectory()
    if not exists(reflectance_destination_directory):
        os.makedirs(reflectance_destination_directory)

    # get reflectance
    goniometer.get_reflectance(average_flux_data_output_directory, average_reference_data_output_directory,
                               reflectance_destination_directory, reference_value=reference_reflectance,
                               output_mode=reflectance_mode)

    # plot scatter plain
    goniometer.plot_scatter_plain(reflectance_destination_directory, incidence_angles, read_mode=reflectance_mode)


def get_reference():
    # check that data directory in goniometer library is set correctly
    try:
        if goniometer.data_folder_directory is not None:
            pass
        else:
            raise TypeError
    except TypeError:
        print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
        exit()

    # Get Reference
    goniometer.get_reference(captures, azimuth_width_px, reference_material, incidence_angles)


def get_background():
    # check that data directory in goniometer library is set correctly
    try:
        if goniometer.data_folder_directory is not None:
            pass
        else:
            raise TypeError
    except TypeError:
        print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
        exit()

    # get_background
    goniometer.get_background(captures, incidence_angles)


def get_snr():
    # check that data directory in goniometer library is set correctly
    try:
        if goniometer.data_folder_directory is not None:
            pass
        else:
            raise TypeError
    except TypeError:
        print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
        exit()

    # get_SNR
    goniometer.flux_signal_to_noise(captures, azimuth_width_px, snr_stack_number, snr_material, incidence_angles)


def get_data_collection_area():
    # check that user has set the directory
    try:
        if goniometer.data_folder_directory is not None:
            pass
        else:
            raise TypeError
    except TypeError:
        print(Fore.RED + "TypeError: Missing Data Folder Directory")
        exit()

    # set up the data collection ares using interactive utility
    goniometer.set_data_collection_areas()


def calibrate():
    # check that user has set the directory
    try:
        if goniometer.data_folder_directory is not None:
            pass
        else:
            raise TypeError
    except TypeError:
        print(Fore.RED + "TypeError: Missing Data Folder Directory")
        exit()

    # calibrate the line equations using interactive utility
    goniometer.calibrate()


def check_calibration():
    # check that user has set the directory
    try:
        if goniometer.data_folder_directory is not None:
            pass
        else:
            raise TypeError
    except TypeError:
        print(Fore.RED + "TypeError: Missing Data Folder Directory")
        exit()

    # check the calibration
    goniometer.check_calibration(zenith_led_bit, captures)


class UiMainWindow(object):
    def __init__(self):
        self.actionPrecision_Mode = None
        self.actionFast_Mode = None
        self.actionSNR = None
        self.actionReference = None
        self.actionBackground = None
        self.actionImage = None
        self.statusbar = None
        self.menuMode = None
        self.menuExposure = None
        self.menuTools = None
        self.menuLoad = None
        self.actionFast_Exposure = None
        self.actionPrecision_Exposures = None
        self.menuFile = None
        self.menubar = None
        self.run_get_collection_area = None
        self.run_get_SNR = None
        self.run_check_calibration = None
        self.run_calibrate = None
        self.run_get_reference = None
        self.run_get_background = None
        self.run_main = None
        self.title = None
        self.central_widget = None

    def setup_ui(self, main_window):
        # main window
        main_window.setObjectName("MainWindow")
        main_window.resize(274, 362)
        self.central_widget = QtWidgets.QWidget(main_window)
        self.central_widget.setObjectName("central-widget")
        self.title = QtWidgets.QLabel(self.central_widget)
        self.title.setGeometry(QtCore.QRect(40, 0, 251, 17))
        self.title.setObjectName("title")
        # get reflectance button
        self.run_main = QtWidgets.QPushButton(self.central_widget)
        self.run_main.setGeometry(QtCore.QRect(10, 30, 251, 41))
        self.run_main.setObjectName("run_main")
        self.run_main.clicked.connect(get_reflectance)

        # get background button
        self.run_get_background = QtWidgets.QPushButton(self.central_widget)
        self.run_get_background.setGeometry(QtCore.QRect(10, 130, 251, 25))
        self.run_get_background.setObjectName("run_get_background")
        self.run_get_background.clicked.connect(get_background)

        # get reference button
        self.run_get_reference = QtWidgets.QPushButton(self.central_widget)
        self.run_get_reference.setGeometry(QtCore.QRect(10, 80, 251, 41))
        self.run_get_reference.setObjectName("run_get_reference")
        self.run_get_reference.clicked.connect(get_reference)

        # calibrate button
        self.run_calibrate = QtWidgets.QPushButton(self.central_widget)
        self.run_calibrate.setGeometry(QtCore.QRect(10, 250, 251, 31))
        self.run_calibrate.setObjectName("run_calibrate")
        self.run_calibrate.clicked.connect(calibrate)

        # check calibration button
        self.run_check_calibration = QtWidgets.QPushButton(self.central_widget)
        self.run_check_calibration.setGeometry(QtCore.QRect(10, 290, 251, 25))
        self.run_check_calibration.setObjectName("run_check_calibration")
        self.run_check_calibration.clicked.connect(check_calibration)

        # get SNR button
        self.run_get_SNR = QtWidgets.QPushButton(self.central_widget)
        self.run_get_SNR.setGeometry(QtCore.QRect(10, 160, 251, 25))
        self.run_get_SNR.setObjectName("run_get_SNR")
        self.run_get_SNR.clicked.connect(get_snr)

        # get data collection areas button
        self.run_get_collection_area = QtWidgets.QPushButton(self.central_widget)
        self.run_get_collection_area.setGeometry(QtCore.QRect(10, 210, 251, 31))
        self.run_get_collection_area.setObjectName("run_get_background_2")
        self.run_get_collection_area.clicked.connect(get_data_collection_area)

        main_window.setCentralWidget(self.central_widget)
        main_window.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(main_window)
        self.statusbar.setObjectName("statusbar")
        main_window.setStatusBar(self.statusbar)
        self.actionImage = QtWidgets.QAction(main_window)
        self.actionImage.setObjectName("actionImage")
        self.actionBackground = QtWidgets.QAction(main_window)
        self.actionBackground.setObjectName("actionBackground")
        self.actionReference = QtWidgets.QAction(main_window)
        self.actionReference.setObjectName("actionReference")
        self.actionSNR = QtWidgets.QAction(main_window)
        self.actionSNR.setObjectName("actionSNR")
        self.actionFast_Mode = QtWidgets.QAction(main_window)
        self.actionFast_Mode.setObjectName("actionFast_Mode")
        self.actionPrecision_Mode = QtWidgets.QAction(main_window)
        self.actionPrecision_Mode.setObjectName("actionPrecision_Mode")
        self.actionFast_Exposure = QtWidgets.QAction(main_window)
        self.actionFast_Exposure.setObjectName("actionFast_Exposure")
        self.actionPrecision_Exposures = QtWidgets.QAction(main_window)
        self.actionPrecision_Exposures.setObjectName("actionPrecision_Exposures")

        self.retranslate_ui(main_window)
        QtCore.QMetaObject.connectSlotsByName(main_window)

    def retranslate_ui(self, main_window):
        _translate = QtCore.QCoreApplication.translate
        main_window.setWindowTitle(_translate("GP03", "GP03"))
        self.run_main.setText(_translate("MainWindow", "Measure Reflectance"))
        self.title.setText(_translate("MainWindow", "GP03 Rapid Photogoniometer"))
        self.run_get_background.setText(_translate("MainWindow", "Measure Background"))
        self.run_get_reference.setText(_translate("MainWindow", "Measure Reference"))
        self.run_calibrate.setText(_translate("MainWindow", "Calibrate"))
        self.run_check_calibration.setText(_translate("MainWindow", "Check Calibration"))
        self.run_get_SNR.setText(_translate("MainWindow", "Measure SNR"))
        self.run_get_collection_area.setText(_translate("MainWindow", "Set Data Collection Areas"))
        self.actionImage.setText(_translate("MainWindow", "Image"))
        self.actionBackground.setText(_translate("MainWindow", "Background"))
        self.actionReference.setText(_translate("MainWindow", "Reference"))
        self.actionSNR.setText(_translate("MainWindow", "SNR"))
        self.actionFast_Mode.setText(_translate("MainWindow", "Fast Mode"))
        self.actionPrecision_Mode.setText(_translate("MainWindow", "Precision Mode"))
        self.actionFast_Exposure.setText(_translate("MainWindow", "Fast Exposure"))
        self.actionPrecision_Exposures.setText(_translate("MainWindow", "Precision Exposures"))


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = UiMainWindow()
    ui.setup_ui(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())