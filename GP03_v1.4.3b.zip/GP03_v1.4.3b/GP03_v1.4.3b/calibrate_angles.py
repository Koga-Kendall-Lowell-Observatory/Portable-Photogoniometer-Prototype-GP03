import goniometer
from colorama import Fore

led_bit = 0
captures = 10

# check that user has set the directory
try:
    if goniometer.data_folder_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder Directory")
    exit()

# calibrate the line equations
goniometer.calibrate_angles()
