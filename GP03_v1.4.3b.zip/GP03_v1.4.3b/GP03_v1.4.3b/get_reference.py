import goniometer
from colorama import Fore

captures = 10
azimuth_width_px = 5
material_name = 'spectralon'

# check that data directory in goniometer library is set correctly
try:
    if goniometer.data_folder_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
    exit()

# Get Reference
goniometer.get_reference(captures, azimuth_width_px, material_name)
