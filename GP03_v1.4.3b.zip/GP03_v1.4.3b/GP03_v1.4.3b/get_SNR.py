import goniometer
from colorama import Fore

captures = 10
width = 5
sn_stack_num = 100
material_name = 'spectralon'

# check that data directory in goniometer library is set correctly
try:
    if goniometer.data_folder_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
    exit()

# get_SNR
goniometer.flux_signal_to_noise(captures, width, sn_stack_num, material_name)
