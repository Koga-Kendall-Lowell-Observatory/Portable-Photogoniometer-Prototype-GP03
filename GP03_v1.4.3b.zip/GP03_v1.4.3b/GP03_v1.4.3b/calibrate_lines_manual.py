import goniometer
from colorama import Fore

# READ ME ##############################################################################################################
# This program allows the operator to manually calibrate the line positions if the stored line coefficients have become
# corrupted. This is not the recommended way to calibrate the device as manual interaction with the code MAY be
# required.
#
# To perform calibration the operator may need to uncomment and re-comment the different 'Show Scan Region(s)' code for
# each line A-G. This type of interaction may be necessary because the code will throw errors if the scan regions do not
# FULLY cover the reflective lines. This is only recommended for advanced users.
#
# This is NOT THE RECOMMENDED WAY to calibrate the device, and is meant as a LAST RESORT option.
########################################################################################################################

led_bit = 0
captures = 10

# check that user has set the directory
try:
    if goniometer.data_folder_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder Directory")
    exit()

# calibrate the line equations
goniometer.calibrate_lines_manual(led_bit, captures)
