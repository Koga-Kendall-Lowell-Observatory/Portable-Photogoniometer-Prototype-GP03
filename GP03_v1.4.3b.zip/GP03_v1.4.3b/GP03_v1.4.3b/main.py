import goniometer
from colorama import Fore

# initialize variables
captures = 10
reference_reff = 1
reference_material = 'spectralon'
snr_material = 'spectralon'
snr_stack_number = 100
# Data Folder Directory & REFF Storage Directory #######################################################################
data_folder_directory = None
reff_destination_directory = None
########################################################################################################################

# check that data directory in goniometer library is set correctly
try:
    if data_folder_directory and reff_destination_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder and/or REFF Destination Directories")
    exit()

try:
    if goniometer.data_folder_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
    exit()

latitude_size_degrees = 3.87
spot_size_mm = 20
azimuth_width_px = 5
incidence_angles = [0, 15, 30, 45, 60, 75]

average_flux_data_input_directory = data_folder_directory + '/temp/flux_data'
average_flux_data_output_directory = data_folder_directory + '/temp/averaged_data/flux'
average_reference_data_input_directory = data_folder_directory + '/reference_library/' + reference_material + '_' +\
                                         str(captures) + '_width_' + str(azimuth_width_px)
average_reference_data_output_directory = data_folder_directory + '/temp/averaged_data/reference'
snr_directory = data_folder_directory + '/snr_library/' + str(snr_material) + '_snr_' + str(captures) + '_' \
                + str(snr_stack_number)

# gather flux data
goniometer.get_data(captures, azimuth_width_px)

# average flux data
print('Processing Flux:')
goniometer.average_data(average_flux_data_input_directory, average_flux_data_output_directory, snr_directory,
                        latitude_size_degrees, spot_size_mm, azimuth_width_px)
# average reference data
print('Processing Reference Flux:')
goniometer.average_data(average_reference_data_input_directory, average_reference_data_output_directory,
                        snr_directory, latitude_size_degrees, spot_size_mm, azimuth_width_px)
# get reff
goniometer.get_reff(average_flux_data_output_directory, average_reference_data_output_directory,
                    reff_destination_directory, reference_reff)

# plot scatter plain
goniometer.plot_scatter_plain(reff_destination_directory)
