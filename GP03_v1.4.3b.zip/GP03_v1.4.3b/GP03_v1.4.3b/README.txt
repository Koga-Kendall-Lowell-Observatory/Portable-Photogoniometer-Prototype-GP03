This is your per-configured default file structure the device is designed to use! Take some time to look around and see where all your directories are. You'll need to know the paths to these directories when you configure your GP03 prototype.

You will need to configure 2 of the .py files, the main goniometer.py library file, and the main.py file which will be the file you use to gather REFF data.

The "GP03_v1.4.3b/data/backup_calibration" directory will not auto populate, this is because it's a place for the user to save a backup of their calibration polynomials in case the main calibration polynomials in the "data" folder get corrupted or accidentally deleted. It is highly recommended that the user uses this directory because the current method of calibrating the line polynomials is a long and difficult task for this version of the prototype. An easier method of calibration is in the works but is not finished yet.

Happy sciencing!
