from uldaq import (get_daq_device_inventory, DaqDevice, InterfaceType, DigitalDirection)
# Install opencv version 4.5.5.64, new versions lack certain built-in functions install opencv-python through the
# pycharm package manager after fully installing the OpenCV C library directory though the terminal.
import cv2
from xlwt import Workbook
from xlrd import open_workbook
import os
from os.path import exists
import numpy as np
import math
import matplotlib.pyplot as plt
import pandas as pd

# Goniometer GP03
# Code Version: v1.4.6b
# Institution: Lowell Observatory
# Developer: Kendall Koga
# Date: 01/13/2023

# DEVICE CONFIGURATION
########################################################################################################################
# Fast Mode Toggle
fast_mode = True
# Fast Mode Exposure Settings
fast_exposure = None
# Precision Mode Exposure Settings
r_exposure = None
g_exposure = None
b_exposure = None
# Hardcoded Hardware Variables
# Camera Index
camera_index = None
# Data Folder Directory
data_folder_directory = None
# Horizontal Resolution (ex: 1920)
horizontal_resolution = None
# Vertical Resolution (ex: 1080)
vertical_resolution = None
# Line i (computer image vertical axis) start and end points
# Line A
a_i_range_min = None
a_i_range_max = None
# Line B
b_i_range_min = None
b_i_range_max = None
# Line C
c_i_range_min = None
c_i_range_max = None
# Line D
d_i_range_min = None
d_i_range_max = None
# Line E
e_i_range_min = None
e_i_range_max = None
# Line F
f_i_range_min = None
f_i_range_max = None
# Line G
g_i_range_min = None
g_i_range_max = None

# Data Ranges
# Line A
a_i_range = a_i_range_max - a_i_range_min
# Line B
b_i_range = b_i_range_max - b_i_range_min
# Line C
c_i_range = c_i_range_max - c_i_range_min
# Line D
d_i_range = d_i_range_max - d_i_range_min
# Line E
e_i_range = e_i_range_max - e_i_range_min
# Line F
f_i_range = f_i_range_max - f_i_range_min
# Line G
g_i_range = g_i_range_max - g_i_range_min
########################################################################################################################

def take_picture(led_bit, captures):
    # ******************************************************************************************************************
    # GET RAW IMAGE DATA ***********************************************************************************************
    # ******************************************************************************************************************

    # SET UP CAMERA*****************************************************************************************************
    cv2.getBuildInformation()
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, horizontal_resolution)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, vertical_resolution)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    # SET UP DAC *******************************************************************************************************
    # find connected daq device
    devices = get_daq_device_inventory(InterfaceType.USB)
    # create daq object
    daq_device = DaqDevice(devices[0])
    dio_device = daq_device.get_dio_device()
    daq_device.connect(connection_code=0)
    # get port types
    dio_info = dio_device.get_info()
    port_types = dio_info.get_port_types()

    # Port
    port = port_types[0]

    # set bit value
    on = 1
    off = 0

    # Configure Port
    dio_device.d_config_port(port, DigitalDirection.OUTPUT)

    # initialize color channel variable stacks as arrays of zeros with the resolution of the camera image HARDCODED
    r_sample = np.zeros((vertical_resolution, horizontal_resolution))
    g_sample = np.zeros((vertical_resolution, horizontal_resolution))
    b_sample = np.zeros((vertical_resolution, horizontal_resolution))

    # GATHER DATA*******************************************************************************************************
    print('Gathering Lit Samples')
    # LIGHTS ON
    # Set bit 0 to on
    dio_device.d_bit_out(port, led_bit, on)
    # pre-load frame buffer
    for i in range(3):
        ret, frame = cap.read()
    # Fast Mode
    if fast_mode:
        cap.set(cv2.CAP_PROP_EXPOSURE, fast_exposure)
        for i in range(captures):
            # TAKE PICTURE
            ret, frame = cap.read()

            # SPLIT IMAGE CHANNELS
            r_sample += frame[:, :, 2]
            g_sample += frame[:, :, 1]
            b_sample += frame[:, :, 0]

            # loop monitor
            print(i)
    # Precision Mode
    elif not fast_mode:
        for i in range(captures):
            # TAKE RED PICTURE
            cap.set(cv2.CAP_PROP_EXPOSURE, r_exposure)
            ret, frame = cap.read()
            r_sample += frame[:, :, 2]
            # TAKE GREEN PICTURE
            cap.set(cv2.CAP_PROP_EXPOSURE, g_exposure)
            ret, frame = cap.read()
            g_sample += frame[:, :, 1]
            # TAKE BLUE PICTURE
            cap.set(cv2.CAP_PROP_EXPOSURE, b_exposure)
            ret, frame = cap.read()
            b_sample += frame[:, :, 0]

            # loop minitor
            print(i)
    # LIGHTS OFF
    # Set bit 0 to off
    dio_device.d_bit_out(port, led_bit, off)

    r_sample = r_sample / captures
    g_sample = g_sample / captures
    b_sample = b_sample / captures

    sample_frame = np.dstack((np.array(b_sample), np.array(g_sample), np.array(r_sample)))

    # DATA GATHER COMPLETE**********************************************************************************************
    print('Gathering Samples Complete')

    # show max and min values
    print('Red Max: ' + str(np.max(r_sample)))
    print('Red Min: ' + str(np.min(r_sample)))
    print('Green Max: ' + str(np.max(g_sample)))
    print('Green Min: ' + str(np.min(g_sample)))
    print('Blue Max: ' + str(np.max(b_sample)))
    print('Blue Min: ' + str(np.min(b_sample)))

    # save split images
    cv2.imwrite(data_folder_directory + "/r_sample.png", r_sample)
    cv2.imwrite(data_folder_directory + "/g_sample.png", g_sample)
    cv2.imwrite(data_folder_directory + "/b_sample.png", b_sample)

    # save frames
    cv2.imwrite(data_folder_directory + "/sample_frame.png", sample_frame)

    # Disconnect Camera
    cap.release()
    cv2.destroyAllWindows()
    # optional use return
    return b_sample, g_sample, r_sample


def get_image_data(led_bit, captures, incidence_angle):
    # ******************************************************************************************************************
    # GET RAW IMAGE DATA ***********************************************************************************************
    # ******************************************************************************************************************

    # SET UP CAMERA*****************************************************************************************************
    cv2.getBuildInformation()
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, horizontal_resolution)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, vertical_resolution)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    # SET UP DAC *******************************************************************************************************
    # find connected daq device
    devices = get_daq_device_inventory(InterfaceType.USB)
    # create daq object
    daq_device = DaqDevice(devices[0])
    dio_device = daq_device.get_dio_device()
    daq_device.connect(connection_code=0)
    # get port types
    dio_info = dio_device.get_info()
    port_types = dio_info.get_port_types()

    # Port
    port = port_types[0]

    # set bit value
    on = 1
    off = 0

    # Configure Port
    dio_device.d_config_port(port, DigitalDirection.OUTPUT)

    # turn on finder light and wait for user input
    # LIGHT ON
    # Set bit 0 to on
    dio_device.d_bit_out(port, 0, 1)
    input("Finder Light On, Press Enter To Continue...\n")
    # LIGHT OFF
    # Set bit 0 to off
    dio_device.d_bit_out(port, 0, 0)

    # initialize color channel variable stacks as arrays of zeros with the resolution of the camera image HARDCODED
    r_data = np.zeros((vertical_resolution, horizontal_resolution))
    g_data = np.zeros((vertical_resolution, horizontal_resolution))
    b_data = np.zeros((vertical_resolution, horizontal_resolution))

    # GATHER DATA*******************************************************************************************************
    print('Gathering Lit Samples')
    # LIGHTS ON
    # Set bit to on
    dio_device.d_bit_out(port, led_bit, on)
    # pre-load frame buffer
    for i in range(3):
        ret, frame = cap.read()
    # Fast Mode
    if fast_mode:
        cap.set(cv2.CAP_PROP_EXPOSURE, fast_exposure)
        for i in range(captures):
            # TAKE PICTURE
            ret, frame = cap.read()

            # SPLIT IMAGE CHANNELS
            r_data += frame[:, :, 2]
            g_data += frame[:, :, 1]
            b_data += frame[:, :, 0]

            # loop monitor
            print(i)
    # Precision Mode
    elif not fast_mode:
        for i in range(captures):
            # TAKE RED PICTURE
            cap.set(cv2.CAP_PROP_EXPOSURE, r_exposure)
            ret, frame = cap.read()
            r_data += frame[:, :, 2]
            # TAKE GREEN PICTURE
            cap.set(cv2.CAP_PROP_EXPOSURE, g_exposure)
            ret, frame = cap.read()
            g_data += frame[:, :, 1]
            # TAKE BLUE PICTURE
            cap.set(cv2.CAP_PROP_EXPOSURE, b_exposure)
            ret, frame = cap.read()
            b_data += frame[:, :, 0]

            # loop minitor
            print(i)
    # LIGHTS OFF
    # Set bit 0 to off
    dio_device.d_bit_out(port, led_bit, off)

    r_data = r_data / captures
    g_data = g_data / captures
    b_data = b_data / captures

    background = cv2.imread(data_folder_directory + '/background/incidence_' + str(incidence_angle) + '_background.png')

    r_data = r_data - background[:, :, 2]
    g_data = g_data - background[:, :, 1]
    b_data = b_data - background[:, :, 0]

    r_data[r_data < 0] = 0.001
    g_data[g_data < 0] = 0.001
    b_data[b_data < 0] = 0.001

    data_frame = np.dstack((np.array(b_data), np.array(g_data), np.array(r_data)))

    # DATA GATHER COMPLETE**********************************************************************************************
    print('Gathering Samples Complete')

    # show max and min values
    print('Red Max: ' + str(np.max(r_data)))
    print('Red Min: ' + str(np.min(r_data)))
    print('Green Max: ' + str(np.max(g_data)))
    print('Green Min: ' + str(np.min(g_data)))
    print('Blue Max: ' + str(np.max(b_data)))
    print('Blue Min: ' + str(np.min(b_data)))

    # save split images
    cv2.imwrite(data_folder_directory + "/r_data.png", r_data)
    cv2.imwrite(data_folder_directory + "/g_data.png", g_data)
    cv2.imwrite(data_folder_directory + "/b_data.png", b_data)

    # save frames
    cv2.imwrite(data_folder_directory + "/data_frame.png", data_frame)

    # Disconnect Camera
    cap.release()
    cv2.destroyAllWindows()

    return b_data, g_data, r_data


def collect_data(captures):
    incidence_angles = [0, 15, 30, 45, 60, 75]

    # SET UP CAMERA*****************************************************************************************************
    cv2.getBuildInformation()
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, horizontal_resolution)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, vertical_resolution)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    # SET UP DAC *******************************************************************************************************
    # find connected daq device
    devices = get_daq_device_inventory(InterfaceType.USB)
    # create daq object
    daq_device = DaqDevice(devices[0])
    dio_device = daq_device.get_dio_device()
    daq_device.connect(connection_code=0)
    # get port types
    dio_info = dio_device.get_info()
    port_types = dio_info.get_port_types()

    # Port
    port = port_types[0]

    # set bit value
    on = 1
    off = 0

    # Configure Port
    dio_device.d_config_port(port, DigitalDirection.OUTPUT)

    # turn on finder light and wait for user input
    # LIGHT ON
    # Set bit 0 to on
    dio_device.d_bit_out(port, 0, 1)
    input("Finder Light On, Press Enter To Continue...\n")
    # LIGHT OFF
    # Set bit 0 to off
    dio_device.d_bit_out(port, 0, 0)

    # frame storage array
    data_frames = np.zeros((len(incidence_angles), vertical_resolution, horizontal_resolution, 3))

    # GATHER DATA*******************************************************************************************************
    print('Gathering Data...')
    # iterate though angles of incidence to store frames
    for incidence_index in range(len(incidence_angles)):
        # LIGHTS ON
        # Set bit to on
        dio_device.d_bit_out(port, incidence_index, on)
        # pre-load frame buffer
        for i in range(3):
            ret, frame = cap.read()
        # Fast Mode
        if fast_mode:
            cap.set(cv2.CAP_PROP_EXPOSURE, fast_exposure)
            for i in range(captures + 1):
                # TAKE PICTURE
                ret, frame = cap.read()
                if i != 0:
                    data_frames[incidence_index] += frame
                    # loop monitor
                    print(i)
        # Precision Mode
        elif not fast_mode:
            for i in range(captures):
                # TAKE RED PICTURE
                cap.set(cv2.CAP_PROP_EXPOSURE, r_exposure)
                ret, frame = cap.read()
                data_frames[incidence_index, :, :, 2] += frame[:, :, 2]
                # TAKE GREEN PICTURE
                cap.set(cv2.CAP_PROP_EXPOSURE, g_exposure)
                ret, frame = cap.read()
                data_frames[incidence_index, :, :, 1] += frame[:, :, 1]
                # TAKE BLUE PICTURE
                cap.set(cv2.CAP_PROP_EXPOSURE, b_exposure)
                ret, frame = cap.read()
                data_frames[incidence_index, :, :, 0] += frame[:, :, 0]
                # loop minitor
                print(i)
        # LIGHTS OFF
        # Set bit 0 to off
        dio_device.d_bit_out(port, incidence_index, off)

    # Disconnect Camera
    cap.release()
    cv2.destroyAllWindows()

    print('==Data Gathering Complete==')

    for incidence_index in range(len(incidence_angles)):
        background = cv2.imread(
            data_folder_directory + '/background/incidence_' + str(incidence_angles[incidence_index])
            + '_background.png')
        data_frames[incidence_index] = (data_frames[incidence_index] / captures) - background
        # save frames
        cv2.imwrite(data_folder_directory + "/data_frame_" + str(incidence_angles[incidence_index])
                    + ".png", data_frames[incidence_index])

    return data_frames


def get_data(captures, azimuth_width_px):
    incidence_angles = [0, 15, 30, 45, 60, 75]
    # Get Picture with internal function
    data = collect_data(captures)
    print('==Processing Data...==')
    # ******************************************************************************************************************
    # GET PHOTON FLUX DATA *********************************************************************************************
    # ******************************************************************************************************************

    # STORE FLUX
    # Create Excel file Workbook
    wb = Workbook()
    spreadsheet = wb.add_sheet('data', cell_overwrite_ok=True)
    spreadsheet.write(0, 0, "A Flux:")
    spreadsheet.write(1, 0, "Theta")
    spreadsheet.write(1, 1, "Blue")
    spreadsheet.write(1, 2, "Green")
    spreadsheet.write(1, 3, "Red")

    spreadsheet.write(0, 5, "B Flux:")
    spreadsheet.write(1, 5, "Theta")
    spreadsheet.write(1, 6, "Blue")
    spreadsheet.write(1, 7, "Green")
    spreadsheet.write(1, 8, "Red")

    spreadsheet.write(0, 10, "C Flux:")
    spreadsheet.write(1, 10, "Theta")
    spreadsheet.write(1, 11, "Blue")
    spreadsheet.write(1, 12, "Green")
    spreadsheet.write(1, 13, "Red")

    spreadsheet.write(0, 15, "D Flux:")
    spreadsheet.write(1, 15, "Theta")
    spreadsheet.write(1, 16, "Blue")
    spreadsheet.write(1, 17, "Green")
    spreadsheet.write(1, 18, "Red")

    spreadsheet.write(0, 20, "E Flux:")
    spreadsheet.write(1, 20, "Theta")
    spreadsheet.write(1, 21, "Blue")
    spreadsheet.write(1, 22, "Green")
    spreadsheet.write(1, 23, "Red")

    spreadsheet.write(0, 25, "F Flux:")
    spreadsheet.write(1, 25, "Theta")
    spreadsheet.write(1, 26, "Blue")
    spreadsheet.write(1, 27, "Green")
    spreadsheet.write(1, 28, "Red")

    spreadsheet.write(0, 30, "G Flux:")
    spreadsheet.write(1, 30, "Theta")
    spreadsheet.write(1, 31, "Blue")
    spreadsheet.write(1, 32, "Green")
    spreadsheet.write(1, 33, "Red")

    for incidence_index in range(len(incidence_angles)):
        # initialize color channel variable stacks as arrays of zeros with the resolution of the camera image HARDCODED
        r = data[incidence_index, :, :, 2]
        g = data[incidence_index, :, :, 1]
        b = data[incidence_index, :, :, 0]

        r[r < 0] = 0.001
        g[g < 0] = 0.001
        b[b < 0] = 0.001

        # save split images
        cv2.imwrite(data_folder_directory + "/r_data_" + str(incidence_angles[incidence_index]) + ".png", r)
        cv2.imwrite(data_folder_directory + "/g_data_" + str(incidence_angles[incidence_index]) + ".png", g)
        cv2.imwrite(data_folder_directory + "/b_data_" + str(incidence_angles[incidence_index]) + ".png", b)

        # A FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_a = a_i_range_min
        a_flux = np.zeros((a_i_range_max - a_i_range_min + 10, 4))
        for i in range(theta_px_a, a_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_a
            # Fill Flux Array
            # angle calculated using polynomial equation
            a_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_a_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_a_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_a_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_a_angle_coefficients.txt").readlines()[3])
            # blue flux
            a_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            a_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            a_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 0, a_flux[n][0])
            spreadsheet.write(n + 2, 1, a_flux[n][1])
            spreadsheet.write(n + 2, 2, a_flux[n][2])
            spreadsheet.write(n + 2, 3, a_flux[n][3])

        # B FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_b = b_i_range_min
        b_flux = np.zeros((b_i_range_max - b_i_range_min + 10, 4))
        for i in range(theta_px_b, b_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_b
            # Fill Flux Array
            # angle calculated using polynomial equation
            b_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_b_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_b_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_b_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_b_angle_coefficients.txt").readlines()[3])
            # blue flux
            b_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            b_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            b_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 5, b_flux[n][0])
            spreadsheet.write(n + 2, 6, b_flux[n][1])
            spreadsheet.write(n + 2, 7, b_flux[n][2])
            spreadsheet.write(n + 2, 8, b_flux[n][3])

        # C FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_c = c_i_range_min
        c_flux = np.zeros((c_i_range_max - c_i_range_min + 10, 4))
        for i in range(theta_px_c, c_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_c
            # Fill Flux Array
            # angle calculated using polynomial equation
            c_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_c_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_c_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_c_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_c_angle_coefficients.txt").readlines()[3])
            # blue flux
            c_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            c_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            c_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 10, c_flux[n][0])
            spreadsheet.write(n + 2, 11, c_flux[n][1])
            spreadsheet.write(n + 2, 12, c_flux[n][2])
            spreadsheet.write(n + 2, 13, c_flux[n][3])

        # D FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_d = d_i_range_min
        d_flux = np.zeros((d_i_range_max - d_i_range_min + 10, 4))
        for i in range(theta_px_d, d_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_d
            # Fill Flux Array
            # angle calculated using polynomial equation
            d_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_d_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_d_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_d_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_d_angle_coefficients.txt").readlines()[3])
            # blue flux
            d_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            d_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            d_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 15, d_flux[n][0])
            spreadsheet.write(n + 2, 16, d_flux[n][1])
            spreadsheet.write(n + 2, 17, d_flux[n][2])
            spreadsheet.write(n + 2, 18, d_flux[n][3])

        # E FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_e = e_i_range_min
        e_flux = np.zeros((e_i_range_max - e_i_range_min + 10, 4))
        for i in range(theta_px_e, e_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_e
            # Fill Flux Array
            # angle calculated using polynomial equation
            e_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_e_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_e_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_e_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_e_angle_coefficients.txt").readlines()[3])
            # blue flux
            e_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            e_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            e_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 20, e_flux[n][0])
            spreadsheet.write(n + 2, 21, e_flux[n][1])
            spreadsheet.write(n + 2, 22, e_flux[n][2])
            spreadsheet.write(n + 2, 23, e_flux[n][3])

        # F FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_f = f_i_range_min
        f_flux = np.zeros((f_i_range_max - f_i_range_min + 10, 4))
        for i in range(theta_px_f, f_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_f
            # Fill Flux Array
            # angle calculated using polynomial equation
            f_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_f_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_f_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_f_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_f_angle_coefficients.txt").readlines()[3])
            # blue flux
            f_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            f_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            f_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 25, f_flux[n][0])
            spreadsheet.write(n + 2, 26, f_flux[n][1])
            spreadsheet.write(n + 2, 27, f_flux[n][2])
            spreadsheet.write(n + 2, 28, f_flux[n][3])

        # G FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_g = g_i_range_min
        g_flux = np.zeros((g_i_range_max - g_i_range_min + 10, 4))
        for i in range(theta_px_g, g_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_g
            # Fill Flux Array
            # angle calculated using polynomial equation
            g_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_g_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_g_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_g_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_g_angle_coefficients.txt").readlines()[3])
            # blue flux
            g_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            g_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            g_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 30, g_flux[n][0])
            spreadsheet.write(n + 2, 31, g_flux[n][1])
            spreadsheet.write(n + 2, 32, g_flux[n][2])
            spreadsheet.write(n + 2, 33, g_flux[n][3])

        # save excel sheet
        wb.save(data_folder_directory + "/temp/flux_data/incidence_" + str(incidence_angles[incidence_index]) +
                "_flux_data.xls")

        # ensure flux data exists before finishing
        while not exists(data_folder_directory + "/temp/flux_data/incidence_" + str(incidence_angles[incidence_index])
                         + "_flux_data.xls"):
            continue

    # END***************************************************************************************************************
    print('==Data Processing Complete==')


def get_reff(sample_flux_data_path, reference_flux_path, output_path, reference_reff):
    print("==Calculating REFF...==")
    # open workbook
    rb_blue_flux = open_workbook(sample_flux_data_path + '/averaged_data_blue.xls')
    blue_flux = rb_blue_flux.sheet_by_index(0)

    rb_green_flux = open_workbook(sample_flux_data_path + '/averaged_data_green.xls')
    green_flux = rb_green_flux.sheet_by_index(0)

    rb_red_flux = open_workbook(sample_flux_data_path + '/averaged_data_red.xls')
    red_flux = rb_red_flux.sheet_by_index(0)

    rb_blue_ref = open_workbook(reference_flux_path + '/averaged_data_blue.xls')
    blue_ref = rb_blue_ref.sheet_by_index(0)

    rb_green_ref = open_workbook(reference_flux_path + '/averaged_data_green.xls')
    green_ref = rb_green_ref.sheet_by_index(0)

    rb_red_ref = open_workbook(reference_flux_path + '/averaged_data_red.xls')
    red_ref = rb_red_ref.sheet_by_index(0)

    # make write sheets by copying read sheets
    wb_blue_reff = Workbook()
    blue_reff = wb_blue_reff.add_sheet('Blue_REFF', cell_overwrite_ok=True)

    wb_green_reff = Workbook()
    green_reff = wb_green_reff.add_sheet('Green_REFF', cell_overwrite_ok=True)

    wb_red_reff = Workbook()
    red_reff = wb_red_reff.add_sheet('Red_REFF', cell_overwrite_ok=True)

    # Make Title Header
    blue_reff.write(0, 0, "Blue Data:")
    green_reff.write(0, 0, "Green Data:")
    red_reff.write(0, 0, "Red Data:")

    # Make Blue Headers
    blue_reff.write(1, 0, "i (Angle of Incidence)")
    blue_reff.write(1, 1, "i % Error")
    blue_reff.write(1, 2, "e (Altitude)")
    blue_reff.write(1, 3, "e Error")
    blue_reff.write(1, 4, "\u03B8 (Azimuth)")
    blue_reff.write(1, 5, "\u03B8 Error")
    blue_reff.write(1, 6, "Blue")
    blue_reff.write(1, 7, "Blue Error")

    # Make Green Headers
    green_reff.write(1, 0, "i (Angle of Incidence)")
    green_reff.write(1, 1, "i Error")
    green_reff.write(1, 2, "e (Altitude)")
    green_reff.write(1, 3, "e Error")
    green_reff.write(1, 4, "\u03B8 (Azimuth)")
    green_reff.write(1, 5, "\u03B8 Error")
    green_reff.write(1, 6, "Green")
    green_reff.write(1, 7, "Green Error")

    # Make Red Headers
    red_reff.write(1, 0, "i (Angle of Incidence)")
    red_reff.write(1, 1, "i Error")
    red_reff.write(1, 2, "e (Altitude)")
    red_reff.write(1, 3, "e Error")
    red_reff.write(1, 4, "\u03B8 (Azimuth)")
    red_reff.write(1, 5, "\u03B8 Error")
    red_reff.write(1, 6, "Red")
    red_reff.write(1, 7, "Red Error")

    # iterate to calculate & store REFF values
    for i in range(2, blue_flux.nrows):
        # fill Excel sheet with data point parameters from flux sheet
        # angle of incidence
        blue_reff.write(i, 0, blue_flux.cell_value(i, 0))
        green_reff.write(i, 0, green_flux.cell_value(i, 0))
        red_reff.write(i, 0, red_flux.cell_value(i, 0))
        # angle of incidence error
        blue_reff.write(i, 1, blue_flux.cell_value(i, 1))
        green_reff.write(i, 1, green_flux.cell_value(i, 1))
        red_reff.write(i, 1, red_flux.cell_value(i, 1))
        # Altitude
        blue_reff.write(i, 2, blue_flux.cell_value(i, 2))
        green_reff.write(i, 2, green_flux.cell_value(i, 2))
        red_reff.write(i, 2, red_flux.cell_value(i, 2))
        # Altitude error
        blue_reff.write(i, 3, blue_flux.cell_value(i, 3))
        green_reff.write(i, 3, green_flux.cell_value(i, 3))
        red_reff.write(i, 3, red_flux.cell_value(i, 3))
        # Azimuth
        blue_reff.write(i, 4, blue_flux.cell_value(i, 4))
        green_reff.write(i, 4, green_flux.cell_value(i, 4))
        red_reff.write(i, 4, red_flux.cell_value(i, 4))
        # Azimuth Error
        blue_reff.write(i, 5, blue_flux.cell_value(i, 5))
        green_reff.write(i, 5, green_flux.cell_value(i, 5))
        red_reff.write(i, 5, red_flux.cell_value(i, 5))

        # get flux values from data spreadsheet
        blue_data = blue_flux.cell_value(i, 6)
        green_data = green_flux.cell_value(i, 6)
        red_data = red_flux.cell_value(i, 6)
        blue_error = blue_flux.cell_value(i, 7)
        green_error = green_flux.cell_value(i, 7)
        red_error = red_flux.cell_value(i, 7)

        # get reference flux values from reference spreadsheet
        blue_ref_data = blue_ref.cell_value(i, 6)
        green_ref_data = green_ref.cell_value(i, 6)
        red_ref_data = red_ref.cell_value(i, 6)

        # calculate values before writing to account for potential division by zero
        # division by zero will be given the value 0
        # blue
        if blue_ref_data == 0:
            blue_write = 0
            blue_error_write = 0
        else:
            blue_write = (blue_data / blue_ref_data) * reference_reff
            blue_error_write = (blue_error / blue_ref_data) * reference_reff
        # green
        if green_ref_data == 0:
            green_write = 0
            green_error_write = 0
        else:
            green_write = (green_data / green_ref_data) * reference_reff
            green_error_write = (green_error / green_ref_data) * reference_reff
        # red
        if red_ref_data == 0:
            red_write = 0
            red_error_write = 0
        else:
            red_write = (red_data / red_ref_data) * reference_reff
            red_error_write = (red_error / red_ref_data) * reference_reff

        # write to Excel file
        blue_reff.write(i, 6, blue_write)
        blue_reff.write(i, 7, blue_error_write)
        green_reff.write(i, 6, green_write)
        green_reff.write(i, 7, green_error_write)
        red_reff.write(i, 6, red_write)
        red_reff.write(i, 7, red_error_write)

    # Check if destination directory exists, if not, create it.
    if not exists(output_path):
        os.makedirs(output_path)

    # save excel sheet
    wb_blue_reff.save(output_path + "/REFF_Blue.xls")
    wb_green_reff.save(output_path + "/REFF_Green.xls")
    wb_red_reff.save(output_path + "/REFF_Red.xls")
    pd.read_excel(output_path + "/REFF_Blue.xls").to_csv(output_path + "/REFF_Blue.csv", index=False)
    pd.read_excel(output_path + "/REFF_Green.xls").to_csv(output_path + "/REFF_Green.csv", index=False)
    pd.read_excel(output_path + "/REFF_Red.xls").to_csv(output_path + "/REFF_Red.csv", index=False)

    print("==REFF Calculation Complete==")



def calibrate_lines_manual(led_bit, captures):
    # Get Picture with internal function
    b, g, r = get_image_data(led_bit, captures, 0)
    width = 5
    print("calibrating")

    # LINE A************************************************************************************************************

    # Position Cache
    position_j = 0
    position_i = 0
    line_pixels = 0
    i_cache = []
    j_cache = []

    # tilt iterator for tilting calibration boxes
    di = 0

    for i in range(190, 610):
        # add to tilt iterator
        di += .65
        for j in range(math.floor(650 - di), math.floor(820 - di)):
            #####################
            # Show Scan Region A
            # b[i][j] = 255
            #####################
            if b[i][j] > 150:
                position_i += i
                position_j += j
                line_pixels += 1
        if line_pixels != 0:
            position_i = int(math.ceil(position_i / line_pixels))
            position_j = int(math.ceil(position_j / line_pixels))
            i_cache.append(position_i)
            j_cache.append(position_j)
        position_i = 0
        position_j = 0
        line_pixels = 0

    # show cache positions for testing purposes
    for i in range(len(i_cache)):
        b[i_cache[i]][j_cache[i]] = 255
    # for i in range(len(angle_i_cache)):
    #    b[angle_i_cache[i]][angle_cache[i]] = 255
    cv2.imwrite(data_folder_directory + "/calibrate_b.jpg", b)

    # FIND LINE A
    line_a_coefficients = np.polyfit(i_cache, j_cache, 3)
    print('LINE A COEFFICIENTS:')
    print(line_a_coefficients)

    # SAVE LINE A
    line_a_file = open(data_folder_directory + "/line_a_coefficients.txt", "w")
    line_a_file.truncate(0)
    for i in range(len(line_a_coefficients)):
        line_a_file.write(str(line_a_coefficients[i]))
        line_a_file.write("\n")
    line_a_file.close()

    # Test Line A Equation
    for i in range(190, 610):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - int(math.ceil(((width - 1) / 2))):j + int(math.ceil(((width - 1) / 2)))] = 0

    # LINE B************************************************************************************************************

    # Position Cache
    position_j = 0
    position_i = 0
    line_pixels = 0
    i_cache = []
    j_cache = []

    # tilt iterator for tilting calibration boxes
    di = 0

    for i in range(220, 580):
        # add to tilt iterator
        di += .62
        for j in range(math.floor(790 - di), math.floor(880 - di)):
            #####################
            # Show Scan Region B
            # b[i][j] = 255
            #####################
            if b[i][j] > 150:
                position_i += i
                position_j += j
                line_pixels += 1
        if line_pixels != 0:
            position_i = int(math.ceil(position_i / line_pixels))
            position_j = int(math.ceil(position_j / line_pixels))
            i_cache.append(position_i)
            j_cache.append(position_j)
        position_i = 0
        position_j = 0
        line_pixels = 0

    # show cache positions for testing purposes
    for i in range(len(i_cache)):
        b[i_cache[i]][j_cache[i]] = 255
    # for i in range(len(angle_i_cache)):
    #    b[angle_i_cache[i]][angle_cache[i]] = 255
    cv2.imwrite(data_folder_directory + "/calibrate_b.jpg", b)

    # FIND LINE B
    line_b_coefficients = np.polyfit(i_cache, j_cache, 3)
    print('LINE B COEFFICIENTS:')
    print(line_b_coefficients)

    # SAVE LINE B
    line_b_file = open(data_folder_directory + "/line_b_coefficients.txt", "w")
    line_b_file.truncate(0)
    for i in range(len(line_b_coefficients)):
        line_b_file.write(str(line_b_coefficients[i]))
        line_b_file.write("\n")
    line_b_file.close()

    # Test Line B Equation
    for i in range(220, 580):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - int(math.ceil(((width - 1) / 2))):j + int(math.ceil(((width - 1) / 2)))] = 0
    # LINE C************************************************************************************************************

    # Clear i and j
    i_cache.clear()
    j_cache.clear()
    # reset tilt iterator
    di = 0

    for i in range(220, 580):
        # add to tilt iterator
        di += .34
        for j in range(math.floor(875 - di), math.floor(920 - di)):
            #####################
            # Show Scan Region C
            # b[i][j] = 255
            #####################
            if b[i][j] > 150:
                position_i += i
                position_j += j
                line_pixels += 1
        if line_pixels != 0:
            position_i = int(math.ceil(position_i / line_pixels))
            position_j = int(math.ceil(position_j / line_pixels))
            i_cache.append(position_i)
            j_cache.append(position_j)
        position_i = 0
        position_j = 0
        line_pixels = 0

    # show cache positions for testing purposes
    for i in range(len(i_cache)):
        b[i_cache[i]][j_cache[i]] = 255
    # for i in range(len(angle_i_cache)):
    #    b[angle_i_cache[i]][angle_cache[i]] = 255
    cv2.imwrite(data_folder_directory + "/calibrate_b.jpg", b)

    # FIND LINE C
    line_c_coefficients = np.polyfit(i_cache, j_cache, 3)
    print('LINE C COEFFICIENTS:')
    print(line_c_coefficients)

    # SAVE LINE C
    line_c_file = open(data_folder_directory + "/line_c_coefficients.txt", "w")
    line_c_file.truncate(0)
    for i in range(len(line_c_coefficients)):
        line_c_file.write(str(line_c_coefficients[i]))
        line_c_file.write("\n")
    line_c_file.close()

    # Test Line C Equation
    for i in range(220, 580):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - int(math.ceil(((width - 1) / 2))):j + int(math.ceil(((width - 1) / 2)))] = 0

    # LINE D************************************************************************************************************

    # Clear i and j
    i_cache.clear()
    j_cache.clear()

    # reset tilt iterator
    di = 0

    for i in range(220, 580):
        for j in range(925, 955):
            #####################
            # Show Scan Region D
            # b[i][j] = 255
            #####################
            if b[i][j] > 150:
                position_i += i
                position_j += j
                line_pixels += 1
        if line_pixels != 0:
            position_i = int(math.ceil(position_i / line_pixels))
            position_j = int(math.ceil(position_j / line_pixels))
            i_cache.append(position_i)
            j_cache.append(position_j)
        position_i = 0
        position_j = 0
        line_pixels = 0

    # show cache positions for testing purposes
    for i in range(len(i_cache)):
        b[i_cache[i]][j_cache[i]] = 255
    # for i in range(len(angle_i_cache)):
    #    b[angle_i_cache[i]][angle_cache[i]] = 255
    cv2.imwrite(data_folder_directory + "/calibrate_b.jpg", b)

    # FIND LINE D
    line_d_coefficients = np.polyfit(i_cache, j_cache, 3)
    print('LINE D COEFFICIENTS:')
    print(line_d_coefficients)

    # SAVE LINE D
    line_d_file = open(data_folder_directory + "/line_d_coefficients.txt", "w")
    line_d_file.truncate(0)
    for i in range(len(line_d_coefficients)):
        line_d_file.write(str(line_d_coefficients[i]))
        line_d_file.write("\n")
    line_d_file.close()

    # Test Line D Equation
    for i in range(220, 580):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - int(math.ceil(((width - 1) / 2))):j + int(math.ceil(((width - 1) / 2)))] = 0

    # LINE E************************************************************************************************************

    # Clear i and j
    i_cache.clear()
    j_cache.clear()

    # reset tilt iterator
    di = 0

    for i in range(220, 580):
        # add to tilt iterator
        di += .36
        for j in range(math.floor(950 + di), math.floor(1005 + di)):
            #####################
            # Show Scan Region E
            # b[i][j] = 255
            #####################
            if b[i][j] > 150:
                position_i += i
                position_j += j
                line_pixels += 1
        if line_pixels != 0:
            position_i = int(math.ceil(position_i / line_pixels))
            position_j = int(math.ceil(position_j / line_pixels))
            i_cache.append(position_i)
            j_cache.append(position_j)
        position_i = 0
        position_j = 0
        line_pixels = 0

    # show cache positions for testing purposes
    for i in range(len(i_cache)):
        b[i_cache[i]][j_cache[i]] = 255
    # for i in range(len(angle_i_cache)):
    #    b[angle_i_cache[i]][angle_cache[i]] = 255
    cv2.imwrite(data_folder_directory + "/calibrate_b.jpg", b)

    # FIND LINE E
    line_e_coefficients = np.polyfit(i_cache, j_cache, 3)
    print('LINE E COEFFICIENTS:')
    print(line_e_coefficients)

    # SAVE LINE E
    line_e_file = open(data_folder_directory + "/line_e_coefficients.txt", "w")
    line_e_file.truncate(0)
    for i in range(len(line_e_coefficients)):
        line_e_file.write(str(line_e_coefficients[i]))
        line_e_file.write("\n")
    line_e_file.close()

    # Test Line E Equation
    for i in range(220, 580):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - int(math.ceil(((width - 1) / 2))):j + int(math.ceil(((width - 1) / 2)))] = 0

    # LINE F************************************************************************************************************

    # Clear i and j
    i_cache.clear()
    j_cache.clear()

    # reset tilt iterator
    di = 0

    for i in range(220, 580):
        # add to tilt iterator
        di += .65
        for j in range(math.floor(990 + di), math.floor(1080 + di)):
            #####################
            # Show Scan Region F
            # b[i][j] = 255
            #####################
            if b[i][j] > 150:
                position_i += i
                position_j += j
                line_pixels += 1
        if line_pixels != 0:
            position_i = int(math.ceil(position_i / line_pixels))
            position_j = int(math.ceil(position_j / line_pixels))
            i_cache.append(position_i)
            j_cache.append(position_j)
        position_i = 0
        position_j = 0
        line_pixels = 0

    # show cache positions for testing purposes
    for i in range(len(i_cache)):
        b[i_cache[i]][j_cache[i]] = 255
    # for i in range(len(angle_i_cache)):
    #   b[angle_i_cache[i]][angle_cache[i]] = 255
    cv2.imwrite(data_folder_directory + "/calibrate_b.jpg", b)

    # FIND LINE F
    line_f_coefficients = np.polyfit(i_cache, j_cache, 3)
    print('LINE F COEFFICIENTS:')
    print(line_f_coefficients)

    # SAVE LINE F
    line_f_file = open(data_folder_directory + "/line_f_coefficients.txt", "w")
    line_f_file.truncate(0)
    for i in range(len(line_f_coefficients)):
        line_f_file.write(str(line_f_coefficients[i]))
        line_f_file.write("\n")
    line_f_file.close()

    # Test Line F Equation
    for i in range(220, 580):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - int(math.ceil(((width - 1) / 2))):j + int(math.ceil(((width - 1) / 2)))] = 0

    # LINE G************************************************************************************************************

    # Clear i and j
    i_cache.clear()
    j_cache.clear()

    # reset tilt iterator
    di = 0

    for i in range(190, 580):
        # add to tilt iterator
        di += .84
        for j in range(math.floor(1040 + di), math.floor(1200 + di)):
            #####################
            # Show Scan Region G
            # b[i][j] = 255
            #####################
            if b[i][j] > 150:
                position_i += i
                position_j += j
                line_pixels += 1
        if line_pixels != 0:
            position_i = int(math.ceil(position_i / line_pixels))
            position_j = int(math.ceil(position_j / line_pixels))
            i_cache.append(position_i)
            j_cache.append(position_j)
        position_i = 0
        position_j = 0
        line_pixels = 0

    # show cache positions for testing purposes
    for i in range(len(i_cache)):
        b[i_cache[i]][j_cache[i]] = 255
    # for i in range(len(angle_i_cache)):
    #   b[angle_i_cache[i]][angle_cache[i]] = 255
    cv2.imwrite(data_folder_directory + "/calibrate_b.jpg", b)

    # FIND LINE G
    line_g_coefficients = np.polyfit(i_cache, j_cache, 3)
    print('LINE G COEFFICIENTS:')
    print(line_g_coefficients)

    # SAVE LINE G
    line_g_file = open(data_folder_directory + "/line_g_coefficients.txt", "w")
    line_g_file.truncate(0)
    for i in range(len(line_g_coefficients)):
        line_g_file.write(str(line_g_coefficients[i]))
        line_g_file.write("\n")
    line_g_file.close()

    # Test Line G Equation
    for i in range(190, 580):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - int(math.ceil(((width - 1) / 2))):j + int(math.ceil(((width - 1) / 2)))] = 0

    # Clear i and j
    i_cache.clear()
    j_cache.clear()

    cv2.imwrite(data_folder_directory + "/calibrate_b.jpg", b)


# Calibrate_angles requires 2 separate functions to operate
# one function to display the coordinates of the points clicked on the image and a global variable to hold the x, y
# coordinates of clicks for each altitude angle
calibration_points = []


def add_point(event, j, i, flags, params):
    global calibration_points
    # checking for left mouse clicks
    if event == cv2.EVENT_LBUTTONDOWN:
        print(j, i)
        if len(calibration_points) != 34:
            calibration_points.append([j, i])
            print('Point Saved')
        elif len(calibration_points) == 34:
            calibration_points.append([j, i])
            print('All Points Selected')
        elif len(calibration_points) > 34:
            print('Point Not Saved: All Points Selected')


def calibrate():
    global calibration_points

    # SET UP DAC *******************************************************************************************************
    # find connected daq device
    devices = get_daq_device_inventory(InterfaceType.USB)
    # create daq object
    daq_device = DaqDevice(devices[0])
    dio_device = daq_device.get_dio_device()
    daq_device.connect(connection_code=0)
    # get port types
    dio_info = dio_device.get_info()
    port_types = dio_info.get_port_types()

    # Port
    port = port_types[0]

    # Configure Port
    dio_device.d_config_port(port, DigitalDirection.OUTPUT)

    # turn on finder light and wait for user input
    # LIGHT ON
    # Set bit 0 to on
    dio_device.d_bit_out(port, 0, 1)
    input("Finder Light On, Press Enter To Continue...\n")
    # LIGHT OFF
    # Set bit 0 to off
    dio_device.d_bit_out(port, 0, 0)

    print("Starting Calibration Utility")

    # LIGHTS ON
    # Set bit 0 to on
    dio_device.d_bit_out(port, 0, 1)

    # SET UP CAMERA*****************************************************************************************************
    cv2.getBuildInformation()
    cap = cv2.VideoCapture(4)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    print('Press Q to end calibration utility.')
    print('Press K to delete previous position point.')
    print('==WARNING==: End utility only after all position points are selected, '
          'failure to do so will could corrupt current calibration and will require the '
          'calibration utility to be run again.')

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()

        pressedkey = cv2.waitKey(1) & 0xFF
        for i in range(len(calibration_points)):
            point_i = calibration_points[i][1]
            point_j = calibration_points[i][0]
            for c in range(-4, 5):
                frame[point_i + c][point_j][:] = 255
                frame[point_i][point_j + c][:] = 255
        # Display the resulting frame
        cv2.imshow('Calibration Stream', frame)
        cv2.setMouseCallback('Calibration Stream', add_point)
        if pressedkey == ord('k'):
            if len(calibration_points) != 0:
                calibration_points.pop(-1)
                print('Deleted Most Recent Point')
            elif len(calibration_points) == 0:
                print('No Points To Delete')
        elif pressedkey == ord('q'):
            break

    # convert calibration_points to a numpy array
    np_calibration_points = np.array(calibration_points)

    # LINE A************************************************************************************************************
    # FIND LINE A
    line_a_coefficients = np.polyfit(np_calibration_points[0:5, 1], np_calibration_points[0:5, 0], 3)
    print('LINE A COEFFICIENTS:')
    print(line_a_coefficients)
    # SAVE LINE A
    line_a_file = open(data_folder_directory + "/line_a_coefficients.txt", "w")
    line_a_file.truncate(0)
    for i in range(len(line_a_coefficients)):
        line_a_file.write(str(line_a_coefficients[i]))
        line_a_file.write("\n")
    line_a_file.close()
    # Test Line A Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[3])))
        frame[i][j][:] = 0
        frame[i][j - 3:j + 3][:] = 0
    # FIND LINE A ANGLES
    a_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[0:5, 1])
    line_a_angle_coefficients = np.polyfit(np_calibration_points[0:5, 1], a_angles, 3)
    # SAVE LINE A ANGLES
    line_a_angle_file = open(data_folder_directory + "/line_a_angle_coefficients.txt", "w")
    line_a_angle_file.truncate(0)
    for i in range(len(line_a_angle_coefficients)):
        line_a_angle_file.write(str(line_a_angle_coefficients[i]))
        line_a_angle_file.write("\n")
    line_a_angle_file.close()

    # LINE B************************************************************************************************************
    # FIND LINE B
    line_b_coefficients = np.polyfit(np_calibration_points[5:10, 1], np_calibration_points[5:10, 0], 3)
    print('LINE B COEFFICIENTS:')
    print(line_b_coefficients)
    # SAVE LINE B
    line_b_file = open(data_folder_directory + "/line_b_coefficients.txt", "w")
    line_b_file.truncate(0)
    for i in range(len(line_b_coefficients)):
        line_b_file.write(str(line_b_coefficients[i]))
        line_b_file.write("\n")
    line_b_file.close()
    # Test Line B Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[3])))
        frame[i][j][:] = 0
        frame[i][j - 3:j + 3][:] = 0
    # FIND LINE B ANGLES
    b_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[5:10, 1])
    line_b_angle_coefficients = np.polyfit(np_calibration_points[5:10, 1], b_angles, 3)
    # SAVE LINE B ANGLES
    line_b_angle_file = open(data_folder_directory + "/line_b_angle_coefficients.txt", "w")
    line_b_angle_file.truncate(0)
    for i in range(len(line_b_angle_coefficients)):
        line_b_angle_file.write(str(line_b_angle_coefficients[i]))
        line_b_angle_file.write("\n")
    line_b_angle_file.close()

    # LINE C************************************************************************************************************
    # FIND LINE C
    line_c_coefficients = np.polyfit(np_calibration_points[10:15, 1], np_calibration_points[10:15, 0], 3)
    print('LINE C COEFFICIENTS:')
    print(line_c_coefficients)
    # SAVE LINE C
    line_c_file = open(data_folder_directory + "/line_c_coefficients.txt", "w")
    line_c_file.truncate(0)
    for i in range(len(line_c_coefficients)):
        line_c_file.write(str(line_c_coefficients[i]))
        line_c_file.write("\n")
    line_c_file.close()
    # Test Line C Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[3])))
        frame[i][j][:] = 0
        frame[i][j - 3:j + 3][:] = 0
    # FIND LINE C ANGLES
    c_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[10:15, 1])
    line_c_angle_coefficients = np.polyfit(np_calibration_points[10:15, 1], c_angles, 3)
    # SAVE LINE C ANGLES
    line_c_angle_file = open(data_folder_directory + "/line_c_angle_coefficients.txt", "w")
    line_c_angle_file.truncate(0)
    for i in range(len(line_c_angle_coefficients)):
        line_c_angle_file.write(str(line_c_angle_coefficients[i]))
        line_c_angle_file.write("\n")
    line_c_angle_file.close()

    # LINE D************************************************************************************************************
    # FIND LINE D
    line_d_coefficients = np.polyfit(np_calibration_points[15:20, 1], np_calibration_points[15:20, 0], 3)
    print('LINE D COEFFICIENTS:')
    print(line_d_coefficients)
    # SAVE LINE D
    line_d_file = open(data_folder_directory + "/line_d_coefficients.txt", "w")
    line_d_file.truncate(0)
    for i in range(len(line_d_coefficients)):
        line_d_file.write(str(line_d_coefficients[i]))
        line_d_file.write("\n")
    line_d_file.close()
    # Test Line D Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[3])))
        frame[i][j][:] = 0
        frame[i][j - 3:j + 3][:] = 0
    # FIND LINE D ANGLES
    d_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[15:20, 1])
    line_d_angle_coefficients = np.polyfit(np_calibration_points[15:20, 1], d_angles, 3)
    # SAVE LINE D ANGLES
    line_d_angle_file = open(data_folder_directory + "/line_d_angle_coefficients.txt", "w")
    line_d_angle_file.truncate(0)
    for i in range(len(line_d_angle_coefficients)):
        line_d_angle_file.write(str(line_d_angle_coefficients[i]))
        line_d_angle_file.write("\n")
    line_d_angle_file.close()

    # LINE E************************************************************************************************************
    # FIND LINE E
    line_e_coefficients = np.polyfit(np_calibration_points[20:25, 1], np_calibration_points[20:25, 0], 3)
    print('LINE E COEFFICIENTS:')
    print(line_e_coefficients)
    # SAVE LINE E
    line_e_file = open(data_folder_directory + "/line_e_coefficients.txt", "w")
    line_e_file.truncate(0)
    for i in range(len(line_e_coefficients)):
        line_e_file.write(str(line_e_coefficients[i]))
        line_e_file.write("\n")
    line_e_file.close()
    # Test Line E Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[3])))
        frame[i][j][:] = 0
        frame[i][j - 3:j + 3][:] = 0
    # FIND LINE E ANGLES
    e_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[20:25, 1])
    line_e_angle_coefficients = np.polyfit(np_calibration_points[20:25, 1], e_angles, 3)
    # SAVE LINE E ANGLES
    line_e_angle_file = open(data_folder_directory + "/line_e_angle_coefficients.txt", "w")
    line_e_angle_file.truncate(0)
    for i in range(len(line_e_angle_coefficients)):
        line_e_angle_file.write(str(line_e_angle_coefficients[i]))
        line_e_angle_file.write("\n")
    line_e_angle_file.close()

    # LINE F************************************************************************************************************
    # FIND LINE F
    line_f_coefficients = np.polyfit(np_calibration_points[25:30, 1], np_calibration_points[25:30, 0], 3)
    print('LINE F COEFFICIENTS:')
    print(line_f_coefficients)
    # SAVE LINE F
    line_f_file = open(data_folder_directory + "/line_f_coefficients.txt", "w")
    line_f_file.truncate(0)
    for i in range(len(line_f_coefficients)):
        line_f_file.write(str(line_f_coefficients[i]))
        line_f_file.write("\n")
    line_f_file.close()
    # Test Line F Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[3])))
        frame[i][j][:] = 0
        frame[i][j - 3:j + 3][:] = 0
    # FIND LINE F ANGLES
    f_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[25:30, 1])
    line_f_angle_coefficients = np.polyfit(np_calibration_points[25:30, 1], f_angles, 3)
    # SAVE LINE F ANGLES
    line_f_angle_file = open(data_folder_directory + "/line_f_angle_coefficients.txt", "w")
    line_f_angle_file.truncate(0)
    for i in range(len(line_f_angle_coefficients)):
        line_f_angle_file.write(str(line_f_angle_coefficients[i]))
        line_f_angle_file.write("\n")
    line_f_angle_file.close()

    # LINE G************************************************************************************************************
    # FIND LINE G
    line_g_coefficients = np.polyfit(np_calibration_points[30:35, 1], np_calibration_points[30:35, 0], 3)
    print('LINE G COEFFICIENTS:')
    print(line_g_coefficients)
    # SAVE LINE G
    line_g_file = open(data_folder_directory + "/line_g_coefficients.txt", "w")
    line_g_file.truncate(0)
    for i in range(len(line_g_coefficients)):
        line_g_file.write(str(line_g_coefficients[i]))
        line_g_file.write("\n")
    line_g_file.close()
    # Test Line G Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[3])))
        frame[i][j][:] = 0
        frame[i][j - 3:j + 3][:] = 0
    # FIND LINE G ANGLES
    g_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[30:35, 1])
    line_g_angle_coefficients = np.polyfit(np_calibration_points[30:35, 1], g_angles, 3)
    # SAVE LINE G ANGLES
    line_g_angle_file = open(data_folder_directory + "/line_g_angle_coefficients.txt", "w")
    line_g_angle_file.truncate(0)
    for i in range(len(line_g_angle_coefficients)):
        line_g_angle_file.write(str(line_g_angle_coefficients[i]))
        line_g_angle_file.write("\n")
    line_g_angle_file.close()

    # Save Calibration
    cv2.imwrite(data_folder_directory + "/calibration.jpg", frame)
    # When everything done, release the capture
    # LIGHTS OFF
    # Set bit 0 to off
    dio_device.d_bit_out(port, 0, 0)
    cap.release()
    cv2.destroyAllWindows()


def calibrate_angles():
    global calibration_points

    # SET UP DAC *******************************************************************************************************
    # find connected daq device
    devices = get_daq_device_inventory(InterfaceType.USB)
    # create daq object
    daq_device = DaqDevice(devices[0])
    dio_device = daq_device.get_dio_device()
    daq_device.connect(connection_code=0)
    # get port types
    dio_info = dio_device.get_info()
    port_types = dio_info.get_port_types()

    # Port
    port = port_types[0]

    # Configure Port
    dio_device.d_config_port(port, DigitalDirection.OUTPUT)

    # turn on finder light and wait for user input
    # LIGHT ON
    # Set bit 0 to on
    dio_device.d_bit_out(port, 0, 1)
    input("Finder Light On, Press Enter To Continue...\n")
    # LIGHT OFF
    # Set bit 0 to off
    dio_device.d_bit_out(port, 0, 0)

    print("Starting Calibration Utility")

    # LIGHTS ON
    # Set bit 0 to on
    dio_device.d_bit_out(port, 0, 1)

    # SET UP CAMERA*****************************************************************************************************
    cv2.getBuildInformation()
    cap = cv2.VideoCapture(4)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, horizontal_resolution)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, vertical_resolution)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    print('Press Q to end calibration utility.')
    print('Press K to delete previous position point.')
    print('==WARNING==: End utility only after all angular position points are selected, '
          'failure to do so will could corrupt current calibration and will require the '
          'calibration utility to be run again.')

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()
        # Load Line A Equation
        for i in range(a_i_range_min, a_i_range_max):
            j = int(
                math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[3])))
            frame[i][j][:] = 0
            frame[i][j - 3:j + 3][:] = 0

        # Load Line B Equation
        for i in range(b_i_range_min, b_i_range_max):
            j = int(
                math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[3])))
            frame[i][j][:] = 0
            frame[i][j - 3:j + 3][:] = 0

        # Load Line C Equation
        for i in range(c_i_range_min, c_i_range_max):
            j = int(
                math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[3])))
            frame[i][j][:] = 0
            frame[i][j - 3:j + 3][:] = 0

        # Load Line D Equation
        for i in range(d_i_range_min, d_i_range_max):
            j = int(
                math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[3])))
            frame[i][j][:] = 0
            frame[i][j - 3:j + 3][:] = 0

        # Load Line E Equation
        for i in range(e_i_range_min, e_i_range_max):
            j = int(
                math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[3])))
            frame[i][j][:] = 0
            frame[i][j - 3:j + 3][:] = 0

        # Load Line F Equation
        for i in range(f_i_range_min, f_i_range_max):
            j = int(
                math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[3])))
            frame[i][j][:] = 0
            frame[i][j - 3:j + 3][:] = 0

        # load Line G Equation
        for i in range(g_i_range_min, g_i_range_max):
            j = int(
                math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[3])))
            frame[i][j][:] = 0
            frame[i][j - 3:j + 3][:] = 0

        pressedkey = cv2.waitKey(1) & 0xFF
        for i in range(len(calibration_points)):
            point_i = calibration_points[i][1]
            point_j = calibration_points[i][0]
            for c in range(-4, 5):
                frame[point_i + c][point_j][:] = 255
                frame[point_i][point_j + c][:] = 255
        # Display the resulting frame
        cv2.imshow('Calibration Stream', frame)
        cv2.setMouseCallback('Calibration Stream', add_point)
        if pressedkey == ord('k'):
            if len(calibration_points) != 0:
                calibration_points.pop(-1)
                print('Deleted Most Recent Point')
            elif len(calibration_points) == 0:
                print('No Points To Delete')
        elif pressedkey == ord('q'):
            break

    # convert calibration_points to a numpy array
    np_calibration_points = np.array(calibration_points)

    # FIND LINE A ANGLES
    a_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[0:5, 1])
    line_a_angle_coefficients = np.polyfit(np_calibration_points[0:5, 1], a_angles, 3)
    # SAVE LINE A ANGLES
    line_a_angle_file = open(data_folder_directory + "/line_a_angle_coefficients.txt", "w")
    line_a_angle_file.truncate(0)
    for i in range(len(line_a_angle_coefficients)):
        line_a_angle_file.write(str(line_a_angle_coefficients[i]))
        line_a_angle_file.write("\n")
    line_a_angle_file.close()

    # FIND LINE B ANGLES
    b_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[5:10, 1])
    line_b_angle_coefficients = np.polyfit(np_calibration_points[5:10, 1], b_angles, 3)
    # SAVE LINE B ANGLES
    line_b_angle_file = open(data_folder_directory + "/line_b_angle_coefficients.txt", "w")
    line_b_angle_file.truncate(0)
    for i in range(len(line_b_angle_coefficients)):
        line_b_angle_file.write(str(line_b_angle_coefficients[i]))
        line_b_angle_file.write("\n")
    line_b_angle_file.close()

    # FIND LINE C ANGLES
    c_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[10:15, 1])
    line_c_angle_coefficients = np.polyfit(np_calibration_points[10:15, 1], c_angles, 3)
    # SAVE LINE C ANGLES
    line_c_angle_file = open(data_folder_directory + "/line_c_angle_coefficients.txt", "w")
    line_c_angle_file.truncate(0)
    for i in range(len(line_c_angle_coefficients)):
        line_c_angle_file.write(str(line_c_angle_coefficients[i]))
        line_c_angle_file.write("\n")
    line_c_angle_file.close()

    # FIND LINE D ANGLES
    d_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[15:20, 1])
    line_d_angle_coefficients = np.polyfit(np_calibration_points[15:20, 1], d_angles, 3)
    # SAVE LINE D ANGLES
    line_d_angle_file = open(data_folder_directory + "/line_d_angle_coefficients.txt", "w")
    line_d_angle_file.truncate(0)
    for i in range(len(line_d_angle_coefficients)):
        line_d_angle_file.write(str(line_d_angle_coefficients[i]))
        line_d_angle_file.write("\n")
    line_d_angle_file.close()

    # FIND LINE E ANGLES
    e_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[20:25, 1])
    line_e_angle_coefficients = np.polyfit(np_calibration_points[20:25, 1], e_angles, 3)
    # SAVE LINE E ANGLES
    line_e_angle_file = open(data_folder_directory + "/line_e_angle_coefficients.txt", "w")
    line_e_angle_file.truncate(0)
    for i in range(len(line_e_angle_coefficients)):
        line_e_angle_file.write(str(line_e_angle_coefficients[i]))
        line_e_angle_file.write("\n")
    line_e_angle_file.close()

    # FIND LINE F ANGLES
    f_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[25:30, 1])
    line_f_angle_coefficients = np.polyfit(np_calibration_points[25:30, 1], f_angles, 3)
    # SAVE LINE F ANGLES
    line_f_angle_file = open(data_folder_directory + "/line_f_angle_coefficients.txt", "w")
    line_f_angle_file.truncate(0)
    for i in range(len(line_f_angle_coefficients)):
        line_f_angle_file.write(str(line_f_angle_coefficients[i]))
        line_f_angle_file.write("\n")
    line_f_angle_file.close()

    # FIND LINE G ANGLES
    g_angles = [75, 60, 45, 30, 15]
    print(np_calibration_points[30:35, 1])
    line_g_angle_coefficients = np.polyfit(np_calibration_points[30:35, 1], g_angles, 3)
    # SAVE LINE G ANGLES
    line_g_angle_file = open(data_folder_directory + "/line_g_angle_coefficients.txt", "w")
    line_g_angle_file.truncate(0)
    for i in range(len(line_g_angle_coefficients)):
        line_g_angle_file.write(str(line_g_angle_coefficients[i]))
        line_g_angle_file.write("\n")
    line_g_angle_file.close()

    # When everything is done, release the capture
    # LIGHTS OFF
    # Set bit 0 to off
    dio_device.d_bit_out(port, 0, 0)
    cap.release()
    cv2.destroyAllWindows()


def check_calibration(led_bit, captures):
    print("calibrating")

    # Get Picture with internal function
    b, g, r = get_image_data(led_bit, captures, 0)

    # Test Line A Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - 3:j + 3] = 0

    # Test Line B Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - 3:j + 3] = 0

    # Test Line C Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - 3:j + 3] = 0

    # Test Line D Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - 3:j + 3] = 0

    # Test Line E Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - 3:j + 3] = 0

    # Test Line F Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - 3:j + 3] = 0

    # Test Line G Equation
    for i in range(10, 640):
        j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[0]))
                          + ((i ** 2) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[1]))
                          + (i * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[2]))
                          + float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[3])))
        b[i][j] = 0
        b[i][j - 3:j + 3] = 0

    cv2.imwrite(data_folder_directory + "/calibrate_b.jpg", b)


def get_sn_data(captures, azimuth_width_px):
    incidence_angles = [0, 15, 30, 45, 60, 75]

    # SET UP CAMERA*****************************************************************************************************
    cv2.getBuildInformation()
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, horizontal_resolution)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, vertical_resolution)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    # SET UP DAC *******************************************************************************************************
    # find connected daq device
    devices = get_daq_device_inventory(InterfaceType.USB)
    # create daq object
    daq_device = DaqDevice(devices[0])
    dio_device = daq_device.get_dio_device()
    daq_device.connect(connection_code=0)
    # get port types
    dio_info = dio_device.get_info()
    port_types = dio_info.get_port_types()

    # Port
    port = port_types[0]

    # set bit value
    on = 1
    off = 0

    # Configure Port
    dio_device.d_config_port(port, DigitalDirection.OUTPUT)

    # frame storage array
    data_frames = np.zeros((len(incidence_angles), vertical_resolution, horizontal_resolution, 3))

    # GATHER DATA*******************************************************************************************************
    print('Gathering Data...')
    # iterate though angles of incidence to store frames
    for incidence_index in range(len(incidence_angles)):
        # LIGHTS ON
        # Set bit 0 to on
        dio_device.d_bit_out(port, incidence_index, on)
        # pre-load frame buffer
        for i in range(3):
            ret, frame = cap.read()
        # Fast Mode
        if fast_mode:
            cap.set(cv2.CAP_PROP_EXPOSURE, fast_exposure)
            for i in range(captures + 1):
                # TAKE PICTURE
                ret, frame = cap.read()
                if i != 0:
                    data_frames[incidence_index] += frame
                    # loop monitor
                    print(i)
        # Precision Mode
        elif not fast_mode:
            r_frame = np.zeros((vertical_resolution, horizontal_resolution))
            g_frame = np.zeros((vertical_resolution, horizontal_resolution))
            b_frame = np.zeros((vertical_resolution, horizontal_resolution))
            for i in range(captures):
                # TAKE RED PICTURE
                cap.set(cv2.CAP_PROP_EXPOSURE, r_exposure)
                ret, frame = cap.read()
                r_frame += frame[:, :, 2]
                # TAKE GREEN PICTURE
                cap.set(cv2.CAP_PROP_EXPOSURE, g_exposure)
                ret, frame = cap.read()
                g_frame += frame[:, :, 1]
                # TAKE BLUE PICTURE
                cap.set(cv2.CAP_PROP_EXPOSURE, b_exposure)
                ret, frame = cap.read()
                b_frame += frame[:, :, 0]
                # Stack Channels
                bgr_frame = np.dstack((np.array(b_frame), np.array(g_frame), np.array(r_frame)))
                data_frames[incidence_index] += bgr_frame
                # loop minitor
                print(i)
        # LIGHTS OFF
        # Set bit 0 to off
        dio_device.d_bit_out(port, incidence_index, off)

    # Disconnect Camera
    cap.release()
    cv2.destroyAllWindows()

    print('==Data Gathering Complete==')
    print('==Processing Data...==')

    for incidence_index in range(len(incidence_angles)):
        background = cv2.imread(
            data_folder_directory + '/background/incidence_' + str(incidence_angles[incidence_index])
            + '_background.png')
        data_frames[incidence_index] = (data_frames[incidence_index] / captures) - background
        # save frames
        cv2.imwrite(data_folder_directory + "/data_frame_" + str(incidence_angles[incidence_index])
                    + ".png", data_frames[incidence_index])

    # Get Picture with internal function
    data = data_frames

    # ******************************************************************************************************************
    # GET PHOTON FLUX DATA *********************************************************************************************
    # ******************************************************************************************************************

    # STORE FLUX
    # Create Excel file Workbook
    wb = Workbook()
    spreadsheet = wb.add_sheet('data', cell_overwrite_ok=True)
    spreadsheet.write(0, 0, "A Flux:")
    spreadsheet.write(1, 0, "Theta")
    spreadsheet.write(1, 1, "Blue")
    spreadsheet.write(1, 2, "Green")
    spreadsheet.write(1, 3, "Red")

    spreadsheet.write(0, 5, "B Flux:")
    spreadsheet.write(1, 5, "Theta")
    spreadsheet.write(1, 6, "Blue")
    spreadsheet.write(1, 7, "Green")
    spreadsheet.write(1, 8, "Red")

    spreadsheet.write(0, 10, "C Flux:")
    spreadsheet.write(1, 10, "Theta")
    spreadsheet.write(1, 11, "Blue")
    spreadsheet.write(1, 12, "Green")
    spreadsheet.write(1, 13, "Red")

    spreadsheet.write(0, 15, "D Flux:")
    spreadsheet.write(1, 15, "Theta")
    spreadsheet.write(1, 16, "Blue")
    spreadsheet.write(1, 17, "Green")
    spreadsheet.write(1, 18, "Red")

    spreadsheet.write(0, 20, "E Flux:")
    spreadsheet.write(1, 20, "Theta")
    spreadsheet.write(1, 21, "Blue")
    spreadsheet.write(1, 22, "Green")
    spreadsheet.write(1, 23, "Red")

    spreadsheet.write(0, 25, "F Flux:")
    spreadsheet.write(1, 25, "Theta")
    spreadsheet.write(1, 26, "Blue")
    spreadsheet.write(1, 27, "Green")
    spreadsheet.write(1, 28, "Red")

    spreadsheet.write(0, 30, "G Flux:")
    spreadsheet.write(1, 30, "Theta")
    spreadsheet.write(1, 31, "Blue")
    spreadsheet.write(1, 32, "Green")
    spreadsheet.write(1, 33, "Red")

    for incidence_index in range(len(incidence_angles)):
        # initialize color channel variable stacks as arrays of zeros with the resolution of the camera image HARDCODED
        r = data[incidence_index, :, :, 2]
        g = data[incidence_index, :, :, 1]
        b = data[incidence_index, :, :, 0]

        r[r < 0] = 0.001
        g[g < 0] = 0.001
        b[b < 0] = 0.001

        # save split images
        cv2.imwrite(data_folder_directory + "/r_data_" + str(incidence_angles[incidence_index]) + ".png", r)
        cv2.imwrite(data_folder_directory + "/g_data_" + str(incidence_angles[incidence_index]) + ".png", g)
        cv2.imwrite(data_folder_directory + "/b_data_" + str(incidence_angles[incidence_index]) + ".png", b)

        # A FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_a = a_i_range_min
        a_flux = np.zeros((a_i_range_max - a_i_range_min + 10, 4))
        for i in range(theta_px_a, a_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_a
            # Fill Flux Array
            # angle calculated using polynomial equation
            a_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_a_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_a_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_a_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_a_angle_coefficients.txt").readlines()[3])
            # blue flux
            a_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            a_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            a_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 0, a_flux[n][0])
            spreadsheet.write(n + 2, 1, a_flux[n][1])
            spreadsheet.write(n + 2, 2, a_flux[n][2])
            spreadsheet.write(n + 2, 3, a_flux[n][3])

        # B FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_b = b_i_range_min
        b_flux = np.zeros((b_i_range_max - b_i_range_min + 10, 4))
        for i in range(theta_px_b, b_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_b
            # Fill Flux Array
            # angle calculated using polynomial equation
            b_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_b_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_b_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_b_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_b_angle_coefficients.txt").readlines()[3])
            # blue flux
            b_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            b_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            b_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 5, b_flux[n][0])
            spreadsheet.write(n + 2, 6, b_flux[n][1])
            spreadsheet.write(n + 2, 7, b_flux[n][2])
            spreadsheet.write(n + 2, 8, b_flux[n][3])

        # C FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_c = c_i_range_min
        c_flux = np.zeros((c_i_range_max - c_i_range_min + 10, 4))
        for i in range(theta_px_c, c_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_c
            # Fill Flux Array
            # angle calculated using polynomial equation
            c_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_c_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_c_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_c_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_c_angle_coefficients.txt").readlines()[3])
            # blue flux
            c_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            c_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            c_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 10, c_flux[n][0])
            spreadsheet.write(n + 2, 11, c_flux[n][1])
            spreadsheet.write(n + 2, 12, c_flux[n][2])
            spreadsheet.write(n + 2, 13, c_flux[n][3])

        # D FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_d = d_i_range_min
        d_flux = np.zeros((d_i_range_max - d_i_range_min + 10, 4))
        for i in range(theta_px_d, d_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_d
            # Fill Flux Array
            # angle calculated using polynomial equation
            d_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_d_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_d_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_d_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_d_angle_coefficients.txt").readlines()[3])
            # blue flux
            d_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            d_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            d_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 15, d_flux[n][0])
            spreadsheet.write(n + 2, 16, d_flux[n][1])
            spreadsheet.write(n + 2, 17, d_flux[n][2])
            spreadsheet.write(n + 2, 18, d_flux[n][3])

        # E FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_e = e_i_range_min
        e_flux = np.zeros((e_i_range_max - e_i_range_min + 10, 4))
        for i in range(theta_px_e, e_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_e
            # Fill Flux Array
            # angle calculated using polynomial equation
            e_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_e_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_e_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_e_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_e_angle_coefficients.txt").readlines()[3])
            # blue flux
            e_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            e_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            e_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 20, e_flux[n][0])
            spreadsheet.write(n + 2, 21, e_flux[n][1])
            spreadsheet.write(n + 2, 22, e_flux[n][2])
            spreadsheet.write(n + 2, 23, e_flux[n][3])

        # F FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_f = f_i_range_min
        f_flux = np.zeros((f_i_range_max - f_i_range_min + 10, 4))
        for i in range(theta_px_f, f_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_f
            # Fill Flux Array
            # angle calculated using polynomial equation
            f_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_f_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_f_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_f_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_f_angle_coefficients.txt").readlines()[3])
            # blue flux
            f_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            f_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            f_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 25, f_flux[n][0])
            spreadsheet.write(n + 2, 26, f_flux[n][1])
            spreadsheet.write(n + 2, 27, f_flux[n][2])
            spreadsheet.write(n + 2, 28, f_flux[n][3])

        # G FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_g = g_i_range_min
        g_flux = np.zeros((g_i_range_max - g_i_range_min + 10, 4))
        for i in range(theta_px_g, g_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_g
            # Fill Flux Array
            # angle calculated using polynomial equation
            g_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_g_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_g_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_g_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_g_angle_coefficients.txt").readlines()[3])
            # blue flux
            g_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            g_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            g_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 30, g_flux[n][0])
            spreadsheet.write(n + 2, 31, g_flux[n][1])
            spreadsheet.write(n + 2, 32, g_flux[n][2])
            spreadsheet.write(n + 2, 33, g_flux[n][3])

        # save excel sheet
        wb.save(data_folder_directory + "/temp/flux_data/incidence_" + str(incidence_angles[incidence_index]) +
                "_flux_data.xls")

        # ensure flux data exists before finishing
        while not exists(data_folder_directory + "/temp/flux_data/incidence_" + str(incidence_angles[incidence_index])
                         + "_flux_data.xls"):
            continue

    # END***************************************************************************************************************
    print('==Data Processing Complete==')


def flux_signal_to_noise(captures, azimuth_width_px, sn_stack_number, material_name):
    # This function lacks the spotlight system so that it does not require user inputs to function.

    storage_path = data_folder_directory + '/snr_library/' + str(material_name) + '_snr_' \
                   + str(captures) + '_' + str(sn_stack_number)
    incidence_angles = [0, 15, 30, 45, 60, 75]

    # Initialize Arrays
    # A Stack
    a_blue_stack = np.zeros((len(incidence_angles), a_i_range, sn_stack_number))
    a_green_stack = np.zeros((len(incidence_angles), a_i_range, sn_stack_number))
    a_red_stack = np.zeros((len(incidence_angles), a_i_range, sn_stack_number))

    # B Stack
    b_blue_stack = np.zeros((len(incidence_angles), b_i_range, sn_stack_number))
    b_green_stack = np.zeros((len(incidence_angles), b_i_range, sn_stack_number))
    b_red_stack = np.zeros((len(incidence_angles), b_i_range, sn_stack_number))

    # C Stack
    c_blue_stack = np.zeros((len(incidence_angles), c_i_range, sn_stack_number))
    c_green_stack = np.zeros((len(incidence_angles), c_i_range, sn_stack_number))
    c_red_stack = np.zeros((len(incidence_angles), c_i_range, sn_stack_number))

    # D Stack
    d_blue_stack = np.zeros((len(incidence_angles), d_i_range, sn_stack_number))
    d_green_stack = np.zeros((len(incidence_angles), d_i_range, sn_stack_number))
    d_red_stack = np.zeros((len(incidence_angles), d_i_range, sn_stack_number))

    # E Stack
    e_blue_stack = np.zeros((len(incidence_angles), e_i_range, sn_stack_number))
    e_green_stack = np.zeros((len(incidence_angles), e_i_range, sn_stack_number))
    e_red_stack = np.zeros((len(incidence_angles), e_i_range, sn_stack_number))

    # F Stack
    f_blue_stack = np.zeros((len(incidence_angles), f_i_range, sn_stack_number))
    f_green_stack = np.zeros((len(incidence_angles), f_i_range, sn_stack_number))
    f_red_stack = np.zeros((len(incidence_angles), f_i_range, sn_stack_number))

    # G Stack
    g_blue_stack = np.zeros((len(incidence_angles), g_i_range, sn_stack_number))
    g_green_stack = np.zeros((len(incidence_angles), g_i_range, sn_stack_number))
    g_red_stack = np.zeros((len(incidence_angles), g_i_range, sn_stack_number))

    # Mean A********************************************************************************************************
    a_blue_stack_mean = np.zeros((len(incidence_angles), a_i_range))
    a_green_stack_mean = np.zeros((len(incidence_angles), a_i_range))
    a_red_stack_mean = np.zeros((len(incidence_angles), a_i_range))

    # Mean B********************************************************************************************************
    b_blue_stack_mean = np.zeros((len(incidence_angles), b_i_range))
    b_green_stack_mean = np.zeros((len(incidence_angles), b_i_range))
    b_red_stack_mean = np.zeros((len(incidence_angles), b_i_range))

    # Mean C********************************************************************************************************
    c_blue_stack_mean = np.zeros((len(incidence_angles), c_i_range))
    c_green_stack_mean = np.zeros((len(incidence_angles), c_i_range))
    c_red_stack_mean = np.zeros((len(incidence_angles), c_i_range))

    # Mean D********************************************************************************************************
    d_blue_stack_mean = np.zeros((len(incidence_angles), d_i_range))
    d_green_stack_mean = np.zeros((len(incidence_angles), d_i_range))
    d_red_stack_mean = np.zeros((len(incidence_angles), d_i_range))

    # Mean E********************************************************************************************************
    e_blue_stack_mean = np.zeros((len(incidence_angles), e_i_range))
    e_green_stack_mean = np.zeros((len(incidence_angles), e_i_range))
    e_red_stack_mean = np.zeros((len(incidence_angles), e_i_range))

    # Mean F********************************************************************************************************
    f_blue_stack_mean = np.zeros((len(incidence_angles), f_i_range))
    f_green_stack_mean = np.zeros((len(incidence_angles), f_i_range))
    f_red_stack_mean = np.zeros((len(incidence_angles), f_i_range))

    # Mean G********************************************************************************************************
    g_blue_stack_mean = np.zeros((len(incidence_angles), g_i_range))
    g_green_stack_mean = np.zeros((len(incidence_angles), g_i_range))
    g_red_stack_mean = np.zeros((len(incidence_angles), g_i_range))

    # STD A*********************************************************************************************************
    a_blue_stack_std = np.zeros((len(incidence_angles), a_i_range))
    a_green_stack_std = np.zeros((len(incidence_angles), a_i_range))
    a_red_stack_std = np.zeros((len(incidence_angles), a_i_range))

    # STD B*********************************************************************************************************
    b_blue_stack_std = np.zeros((len(incidence_angles), b_i_range))
    b_green_stack_std = np.zeros((len(incidence_angles), b_i_range))
    b_red_stack_std = np.zeros((len(incidence_angles), b_i_range))

    # STD C*********************************************************************************************************
    c_blue_stack_std = np.zeros((len(incidence_angles), c_i_range))
    c_green_stack_std = np.zeros((len(incidence_angles), c_i_range))
    c_red_stack_std = np.zeros((len(incidence_angles), c_i_range))

    # STD D*********************************************************************************************************
    d_blue_stack_std = np.zeros((len(incidence_angles), d_i_range))
    d_green_stack_std = np.zeros((len(incidence_angles), d_i_range))
    d_red_stack_std = np.zeros((len(incidence_angles), d_i_range))

    # STD E*********************************************************************************************************
    e_blue_stack_std = np.zeros((len(incidence_angles), e_i_range))
    e_green_stack_std = np.zeros((len(incidence_angles), e_i_range))
    e_red_stack_std = np.zeros((len(incidence_angles), e_i_range))

    # STD F*********************************************************************************************************
    f_blue_stack_std = np.zeros((len(incidence_angles), f_i_range))
    f_green_stack_std = np.zeros((len(incidence_angles), f_i_range))
    f_red_stack_std = np.zeros((len(incidence_angles), f_i_range))

    # STD G*********************************************************************************************************
    g_blue_stack_std = np.zeros((len(incidence_angles), g_i_range))
    g_green_stack_std = np.zeros((len(incidence_angles), g_i_range))
    g_red_stack_std = np.zeros((len(incidence_angles), g_i_range))

    # Get Data For Passed Iterations
    for k in range(0, sn_stack_number):
        print('Iteration: ' + str(k))

        # call function to get flux data
        get_sn_data(captures, azimuth_width_px)

        for incidence_index in range(len(incidence_angles)):
            # get flux data
            wb0 = open_workbook(data_folder_directory + "/temp/flux_data/incidence_"
                                + str(incidence_angles[incidence_index]) + "_flux_data.xls")
            flux_data = wb0.sheet_by_index(0)

            # STACK FLUX A**********************************************************************************************
            for j in range(0, a_i_range):
                a_blue_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 1)
                a_green_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 2)
                a_red_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 3)

            # STACK FLUX B**********************************************************************************************
            for j in range(0, b_i_range):
                b_blue_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 6)
                b_green_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 7)
                b_red_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 8)

            # STACK FLUX C**********************************************************************************************
            for j in range(0, c_i_range):
                c_blue_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 11)
                c_green_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 12)
                c_red_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 13)

            # STACK FLUX D**********************************************************************************************
            for j in range(0, d_i_range):
                d_blue_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 16)
                d_green_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 17)
                d_red_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 18)

            # STACK FLUX E**********************************************************************************************
            for j in range(0, e_i_range):
                e_blue_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 21)
                e_green_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 22)
                e_red_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 23)

            # STACK FLUX F**********************************************************************************************
            for j in range(0, f_i_range):
                f_blue_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 26)
                f_green_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 27)
                f_red_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 28)

            # STACK FLUX G**********************************************************************************************
            for j in range(0, g_i_range):
                g_blue_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 31)
                g_green_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 32)
                g_red_stack[incidence_index][j][k] = flux_data.cell_value(j + 2, 33)

    for incidence_index in range(len(incidence_angles)):
        # Mean A********************************************************************************************************
        a_blue_stack_mean[incidence_index] = a_blue_stack[incidence_index].mean(axis=1)
        a_green_stack_mean[incidence_index] = a_green_stack[incidence_index].mean(axis=1)
        a_red_stack_mean[incidence_index] = a_red_stack[incidence_index].mean(axis=1)

        # Mean B********************************************************************************************************
        b_blue_stack_mean[incidence_index] = b_blue_stack[incidence_index].mean(axis=1)
        b_green_stack_mean[incidence_index] = b_green_stack[incidence_index].mean(axis=1)
        b_red_stack_mean[incidence_index] = b_red_stack[incidence_index].mean(axis=1)

        # Mean C********************************************************************************************************
        c_blue_stack_mean[incidence_index] = c_blue_stack[incidence_index].mean(axis=1)
        c_green_stack_mean[incidence_index] = c_green_stack[incidence_index].mean(axis=1)
        c_red_stack_mean[incidence_index] = c_red_stack[incidence_index].mean(axis=1)

        # Mean D********************************************************************************************************
        d_blue_stack_mean[incidence_index] = d_blue_stack[incidence_index].mean(axis=1)
        d_green_stack_mean[incidence_index] = d_green_stack[incidence_index].mean(axis=1)
        d_red_stack_mean[incidence_index] = d_red_stack[incidence_index].mean(axis=1)

        # Mean E********************************************************************************************************
        e_blue_stack_mean[incidence_index] = e_blue_stack[incidence_index].mean(axis=1)
        e_green_stack_mean[incidence_index] = e_green_stack[incidence_index].mean(axis=1)
        e_red_stack_mean[incidence_index] = e_red_stack[incidence_index].mean(axis=1)

        # Mean F********************************************************************************************************
        f_blue_stack_mean[incidence_index] = f_blue_stack[incidence_index].mean(axis=1)
        f_green_stack_mean[incidence_index] = f_green_stack[incidence_index].mean(axis=1)
        f_red_stack_mean[incidence_index] = f_red_stack[incidence_index].mean(axis=1)

        # Mean G********************************************************************************************************
        g_blue_stack_mean[incidence_index] = g_blue_stack[incidence_index].mean(axis=1)
        g_green_stack_mean[incidence_index] = g_green_stack[incidence_index].mean(axis=1)
        g_red_stack_mean[incidence_index] = g_red_stack[incidence_index].mean(axis=1)

        # STD A*********************************************************************************************************
        a_blue_stack_std[incidence_index] = a_blue_stack[incidence_index].std(axis=1)
        a_green_stack_std[incidence_index] = a_green_stack[incidence_index].std(axis=1)
        a_red_stack_std[incidence_index] = a_red_stack[incidence_index].std(axis=1)

        # STD B*********************************************************************************************************
        b_blue_stack_std[incidence_index] = b_blue_stack[incidence_index].std(axis=1)
        b_green_stack_std[incidence_index] = b_green_stack[incidence_index].std(axis=1)
        b_red_stack_std[incidence_index] = b_red_stack[incidence_index].std(axis=1)

        # STD C*********************************************************************************************************
        c_blue_stack_std[incidence_index] = c_blue_stack[incidence_index].std(axis=1)
        c_green_stack_std[incidence_index] = c_green_stack[incidence_index].std(axis=1)
        c_red_stack_std[incidence_index] = c_red_stack[incidence_index].std(axis=1)

        # STD D*********************************************************************************************************
        d_blue_stack_std[incidence_index] = d_blue_stack[incidence_index].std(axis=1)
        d_green_stack_std[incidence_index] = d_green_stack[incidence_index].std(axis=1)
        d_red_stack_std[incidence_index] = d_red_stack[incidence_index].std(axis=1)

        # STD E*********************************************************************************************************
        e_blue_stack_std[incidence_index] = e_blue_stack[incidence_index].std(axis=1)
        e_green_stack_std[incidence_index] = e_green_stack[incidence_index].std(axis=1)
        e_red_stack_std[incidence_index] = e_red_stack[incidence_index].std(axis=1)

        # STD F*********************************************************************************************************
        f_blue_stack_std[incidence_index] = f_blue_stack[incidence_index].std(axis=1)
        f_green_stack_std[incidence_index] = f_green_stack[incidence_index].std(axis=1)
        f_red_stack_std[incidence_index] = f_red_stack[incidence_index].std(axis=1)

        # STD G*********************************************************************************************************
        g_blue_stack_std[incidence_index] = g_blue_stack[incidence_index].std(axis=1)
        g_green_stack_std[incidence_index] = g_green_stack[incidence_index].std(axis=1)
        g_red_stack_std[incidence_index] = g_red_stack[incidence_index].std(axis=1)

        # get flux data
        wb0 = open_workbook(data_folder_directory + "/temp/flux_data/incidence_"
                            + str(incidence_angles[incidence_index]) + "_flux_data.xls")
        flux_data = wb0.sheet_by_index(0)

        # Create Excel file Workbook
        wb1 = Workbook()
        flux_sn_sheet = wb1.add_sheet('Flux_Signal_to_Noise', cell_overwrite_ok=True)
        wb2 = Workbook()
        flux_avg = wb2.add_sheet('Flux_AVG', cell_overwrite_ok=True)
        wb3 = Workbook()
        flux_stdv = wb3.add_sheet('Flux_STDV', cell_overwrite_ok=True)

        # add SNR headers
        flux_sn_sheet.write(0, 0, "A Flux S/N:")
        flux_sn_sheet.write(1, 0, "Theta")
        flux_sn_sheet.write(1, 1, "Blue")
        flux_sn_sheet.write(1, 2, "Green")
        flux_sn_sheet.write(1, 3, "Red")

        flux_sn_sheet.write(0, 5, "B Flux S/N:")
        flux_sn_sheet.write(1, 5, "Theta")
        flux_sn_sheet.write(1, 6, "Blue")
        flux_sn_sheet.write(1, 7, "Green")
        flux_sn_sheet.write(1, 8, "Red")

        flux_sn_sheet.write(0, 10, "C Flux S/N:")
        flux_sn_sheet.write(1, 10, "Theta")
        flux_sn_sheet.write(1, 11, "Blue")
        flux_sn_sheet.write(1, 12, "Green")
        flux_sn_sheet.write(1, 13, "Red")

        flux_sn_sheet.write(0, 15, "D Flux S/N:")
        flux_sn_sheet.write(1, 15, "Theta")
        flux_sn_sheet.write(1, 16, "Blue")
        flux_sn_sheet.write(1, 17, "Green")
        flux_sn_sheet.write(1, 18, "Red")

        flux_sn_sheet.write(0, 20, "E Flux S/N:")
        flux_sn_sheet.write(1, 20, "Theta")
        flux_sn_sheet.write(1, 21, "Blue")
        flux_sn_sheet.write(1, 22, "Green")
        flux_sn_sheet.write(1, 23, "Red")

        flux_sn_sheet.write(0, 25, "F Flux S/N:")
        flux_sn_sheet.write(1, 25, "Theta")
        flux_sn_sheet.write(1, 26, "Blue")
        flux_sn_sheet.write(1, 27, "Green")
        flux_sn_sheet.write(1, 28, "Red")

        flux_sn_sheet.write(0, 30, "G Flux S/N:")
        flux_sn_sheet.write(1, 30, "Theta")
        flux_sn_sheet.write(1, 31, "Blue")
        flux_sn_sheet.write(1, 32, "Green")
        flux_sn_sheet.write(1, 33, "Red")

        # add average headers
        flux_avg.write(0, 0, "A Flux S/N:")
        flux_avg.write(1, 0, "Theta")
        flux_avg.write(1, 1, "Blue")
        flux_avg.write(1, 2, "Green")
        flux_avg.write(1, 3, "Red")

        flux_avg.write(0, 5, "B Flux S/N:")
        flux_avg.write(1, 5, "Theta")
        flux_avg.write(1, 6, "Blue")
        flux_avg.write(1, 7, "Green")
        flux_avg.write(1, 8, "Red")

        flux_avg.write(0, 10, "C REFF S/N:")
        flux_avg.write(1, 10, "Theta")
        flux_avg.write(1, 11, "Blue")
        flux_avg.write(1, 12, "Green")
        flux_avg.write(1, 13, "Red")

        flux_avg.write(0, 15, "D Flux S/N:")
        flux_avg.write(1, 15, "Theta")
        flux_avg.write(1, 16, "Blue")
        flux_avg.write(1, 17, "Green")
        flux_avg.write(1, 18, "Red")

        flux_avg.write(0, 20, "E Flux S/N:")
        flux_avg.write(1, 20, "Theta")
        flux_avg.write(1, 21, "Blue")
        flux_avg.write(1, 22, "Green")
        flux_avg.write(1, 23, "Red")

        flux_avg.write(0, 25, "F Flux S/N:")
        flux_avg.write(1, 25, "Theta")
        flux_avg.write(1, 26, "Blue")
        flux_avg.write(1, 27, "Green")
        flux_avg.write(1, 28, "Red")

        flux_avg.write(0, 30, "G Flux S/N:")
        flux_avg.write(1, 30, "Theta")
        flux_avg.write(1, 31, "Blue")
        flux_avg.write(1, 32, "Green")
        flux_avg.write(1, 33, "Red")

        # add stdv headers
        flux_stdv.write(0, 0, "A Flux S/N:")
        flux_stdv.write(1, 0, "Theta")
        flux_stdv.write(1, 1, "Blue")
        flux_stdv.write(1, 2, "Green")
        flux_stdv.write(1, 3, "Red")

        flux_stdv.write(0, 5, "B Flux S/N:")
        flux_stdv.write(1, 5, "Theta")
        flux_stdv.write(1, 6, "Blue")
        flux_stdv.write(1, 7, "Green")
        flux_stdv.write(1, 8, "Red")

        flux_stdv.write(0, 10, "C Flux S/N:")
        flux_stdv.write(1, 10, "Theta")
        flux_stdv.write(1, 11, "Blue")
        flux_stdv.write(1, 12, "Green")
        flux_stdv.write(1, 13, "Red")

        flux_stdv.write(0, 15, "D Flux S/N:")
        flux_stdv.write(1, 15, "Theta")
        flux_stdv.write(1, 16, "Blue")
        flux_stdv.write(1, 17, "Green")
        flux_stdv.write(1, 18, "Red")

        flux_stdv.write(0, 20, "E Flux S/N:")
        flux_stdv.write(1, 20, "Theta")
        flux_stdv.write(1, 21, "Blue")
        flux_stdv.write(1, 22, "Green")
        flux_stdv.write(1, 23, "Red")

        flux_stdv.write(0, 25, "F Flux S/N:")
        flux_stdv.write(1, 25, "Theta")
        flux_stdv.write(1, 26, "Blue")
        flux_stdv.write(1, 27, "Green")
        flux_stdv.write(1, 28, "Red")

        flux_stdv.write(0, 30, "G Flux S/N:")
        flux_stdv.write(1, 30, "Theta")
        flux_stdv.write(1, 31, "Blue")
        flux_stdv.write(1, 32, "Green")
        flux_stdv.write(1, 33, "Red")

        # STORE FLUX S/N & AVG A********************************************************************************************
        for j in range(0, a_i_range):
            flux_sn_sheet.write(j + 2, 0, flux_data.cell_value(j + 2, 0))

            flux_avg.write(j + 2, 0, flux_data.cell_value(j + 2, 0))
            flux_avg.write(j + 2, 1, a_blue_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 2, a_green_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 3, a_red_stack_mean[incidence_index][j])

            flux_stdv.write(j + 2, 0, flux_data.cell_value(j + 2, 0))
            flux_stdv.write(j + 2, 1, a_blue_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 2, a_green_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 3, a_red_stack_std[incidence_index][j])
            if a_blue_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 1, a_blue_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 1,
                                    a_blue_stack_mean[incidence_index][j] / a_blue_stack_std[incidence_index][j])
            if a_green_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 2, a_green_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 2,
                                    a_green_stack_mean[incidence_index][j] / a_green_stack_std[incidence_index][j])
            if a_red_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 3, a_red_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 3,
                                    a_red_stack_mean[incidence_index][j] / a_red_stack_std[incidence_index][j])

        # STORE FLUX S/N & AVG B********************************************************************************************
        for j in range(0, b_i_range):
            flux_sn_sheet.write(j + 2, 5, flux_data.cell_value(j + 2, 5))

            flux_avg.write(j + 2, 5, flux_data.cell_value(j + 2, 5))
            flux_avg.write(j + 2, 6, b_blue_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 7, b_green_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 8, b_red_stack_mean[incidence_index][j])

            flux_stdv.write(j + 2, 5, flux_data.cell_value(j + 2, 5))
            flux_stdv.write(j + 2, 6, b_blue_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 7, b_green_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 8, b_red_stack_std[incidence_index][j])
            if b_blue_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 6, b_blue_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 6,
                                    b_blue_stack_mean[incidence_index][j] / b_blue_stack_std[incidence_index][j])
            if b_green_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 7, b_green_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 7,
                                    b_green_stack_mean[incidence_index][j] / b_green_stack_std[incidence_index][j])
            if b_red_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 8, b_red_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 8, b_red_stack_mean[incidence_index][j] / b_red_stack_std[incidence_index][j])

        # STORE FLUX S/N & AVG C********************************************************************************************
        for j in range(0, c_i_range):
            flux_sn_sheet.write(j + 2, 10, flux_data.cell_value(j + 2, 10))

            flux_avg.write(j + 2, 10, flux_data.cell_value(j + 2, 10))
            flux_avg.write(j + 2, 11, c_blue_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 12, c_green_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 13, c_red_stack_mean[incidence_index][j])

            flux_stdv.write(j + 2, 10, flux_data.cell_value(j + 2, 10))
            flux_stdv.write(j + 2, 11, c_blue_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 12, c_green_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 13, c_red_stack_std[incidence_index][j])
            if c_blue_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 11, c_blue_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 11,
                                    c_blue_stack_mean[incidence_index][j] / c_blue_stack_std[incidence_index][j])
            if c_green_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 12, c_green_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 12,
                                    c_green_stack_mean[incidence_index][j] / c_green_stack_std[incidence_index][j])
            if c_red_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 13, c_red_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 13,
                                    c_red_stack_mean[incidence_index][j] / c_red_stack_std[incidence_index][j])

        # STORE FLUX S/N & AVG D********************************************************************************************
        for j in range(0, d_i_range):
            flux_sn_sheet.write(j + 2, 15, flux_data.cell_value(j + 2, 15))

            flux_avg.write(j + 2, 15, flux_data.cell_value(j + 2, 15))
            flux_avg.write(j + 2, 16, d_blue_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 17, d_green_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 18, d_red_stack_mean[incidence_index][j])

            flux_stdv.write(j + 2, 15, flux_data.cell_value(j + 2, 15))
            flux_stdv.write(j + 2, 16, d_blue_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 17, d_green_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 18, d_red_stack_std[incidence_index][j])
            if d_blue_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 16, d_blue_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 16,
                                    d_blue_stack_mean[incidence_index][j] / d_blue_stack_std[incidence_index][j])
            if d_green_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 17, d_green_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 17,
                                    d_green_stack_mean[incidence_index][j] / d_green_stack_std[incidence_index][j])
            if d_red_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 18, d_red_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 18,
                                    d_red_stack_mean[incidence_index][j] / d_red_stack_std[incidence_index][j])

        # STORE FLUX S/N & AVG E********************************************************************************************
        for j in range(0, e_i_range):
            flux_sn_sheet.write(j + 2, 20, flux_data.cell_value(j + 2, 20))

            flux_avg.write(j + 2, 20, flux_data.cell_value(j + 2, 20))
            flux_avg.write(j + 2, 21, e_blue_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 22, e_green_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 23, e_red_stack_mean[incidence_index][j])

            flux_stdv.write(j + 2, 20, flux_data.cell_value(j + 2, 20))
            flux_stdv.write(j + 2, 21, e_blue_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 22, e_green_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 23, e_red_stack_std[incidence_index][j])
            if e_blue_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 21, e_blue_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 21,
                                    e_blue_stack_mean[incidence_index][j] / e_blue_stack_std[incidence_index][j])
            if e_green_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 22, e_green_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 22,
                                    e_green_stack_mean[incidence_index][j] / e_green_stack_std[incidence_index][j])
            if e_red_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 23, e_red_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 23,
                                    e_red_stack_mean[incidence_index][j] / e_red_stack_std[incidence_index][j])

        # STORE FLUX S/N & AVG F********************************************************************************************
        for j in range(0, f_i_range):
            flux_sn_sheet.write(j + 2, 25, flux_data.cell_value(j + 2, 25))

            flux_avg.write(j + 2, 25, flux_data.cell_value(j + 2, 25))
            flux_avg.write(j + 2, 26, f_blue_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 27, f_green_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 28, f_red_stack_mean[incidence_index][j])

            flux_stdv.write(j + 2, 25, flux_data.cell_value(j + 2, 25))
            flux_stdv.write(j + 2, 26, f_blue_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 27, f_green_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 28, f_red_stack_std[incidence_index][j])
            if f_blue_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 26, f_blue_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 26,
                                    f_blue_stack_mean[incidence_index][j] / f_blue_stack_std[incidence_index][j])
            if f_green_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 27, f_green_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 27,
                                    f_green_stack_mean[incidence_index][j] / f_green_stack_std[incidence_index][j])
            if f_red_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 28, f_red_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 28,
                                    f_red_stack_mean[incidence_index][j] / f_red_stack_std[incidence_index][j])

        # STORE FLUX S/N & AVG G********************************************************************************************
        for j in range(0, g_i_range):
            flux_sn_sheet.write(j + 2, 30, flux_data.cell_value(j + 2, 30))

            flux_avg.write(j + 2, 30, flux_data.cell_value(j + 2, 30))
            flux_avg.write(j + 2, 31, g_blue_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 32, g_green_stack_mean[incidence_index][j])
            flux_avg.write(j + 2, 33, g_red_stack_mean[incidence_index][j])

            flux_stdv.write(j + 2, 30, flux_data.cell_value(j + 2, 30))
            flux_stdv.write(j + 2, 31, g_blue_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 32, g_green_stack_std[incidence_index][j])
            flux_stdv.write(j + 2, 33, g_red_stack_std[incidence_index][j])
            if g_blue_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 31, g_blue_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 31,
                                    g_blue_stack_mean[incidence_index][j] / g_blue_stack_std[incidence_index][j])
            if g_green_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 32, g_green_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 32,
                                    g_green_stack_mean[incidence_index][j] / g_green_stack_std[incidence_index][j])
            if g_red_stack_std[incidence_index][j] == 0:
                flux_sn_sheet.write(j + 2, 33, g_red_stack_mean[incidence_index][j])
            else:
                flux_sn_sheet.write(j + 2, 33,
                                    g_red_stack_mean[incidence_index][j] / g_red_stack_std[incidence_index][j])

        if not exists(storage_path):
            os.makedirs(storage_path)

        wb1.save(storage_path + '/incidence_' + str(incidence_angles[incidence_index]) + '_flux_signal_to_noise.xls')
        wb2.save(storage_path + '/incidence_' + str(incidence_angles[incidence_index]) + '_flux_average.xls')
        wb3.save(storage_path + '/incidence_' + str(incidence_angles[incidence_index]) + '_flux_stdv.xls')
    print('==Flux S/N Calculation Complete==')


def plot_scatter_plain(reff_directory):
    incidence_angles = [0, 15, 30, 45, 60, 75]
    colors = ['lightgrey', 'silver', 'darkgray', 'gray', 'dimgray', 'black']

    # initialize plots
    blue_plot = plt.figure(0).add_subplot(111, polar=True)
    green_plot = plt.figure(1).add_subplot(111, polar=True)
    red_plot = plt.figure(2).add_subplot(111, polar=True)

    # pull data from file
    # Blue
    wb0 = open_workbook(reff_directory + '/REFF_Blue.xls')
    blue_file = wb0.sheet_by_index(0)
    # Green
    wb1 = open_workbook(reff_directory + '/REFF_Green.xls')
    green_file = wb1.sheet_by_index(0)
    # Red
    wb2 = open_workbook(reff_directory + '/REFF_Red.xls')
    red_file = wb2.sheet_by_index(0)

    for n in range(len(incidence_angles)):
        # initialize arrays
        # Blue
        altitude_blue = []
        data_blue = []
        # Green
        altitude_green = []
        data_green = []
        # Red
        altitude_red = []
        data_red = []
        for i in range(2, blue_file.nrows):
            if blue_file.cell_value(i, 0) != incidence_angles[n]:
                continue
            elif blue_file.cell_value(i, 4) == 0:
                altitude_blue.append(90 - blue_file.cell_value(i, 2))
                data_blue.append(blue_file.cell_value(i, 6))
            elif blue_file.cell_value(i, 4) == 180:
                altitude_blue.append(180 - (90 - blue_file.cell_value(i, 2)))
                data_blue.append(blue_file.cell_value(i, 6))

        for i in range(2, green_file.nrows):
            if green_file.cell_value(i, 0) != incidence_angles[n]:
                continue
            elif green_file.cell_value(i, 4) == 0:
                altitude_green.append(90 - green_file.cell_value(i, 2))
                data_green.append(green_file.cell_value(i, 6))
            elif green_file.cell_value(i, 4) == 180:
                altitude_green.append(180 - (90 - green_file.cell_value(i, 2)))
                data_green.append(green_file.cell_value(i, 6))

        for i in range(2, red_file.nrows):
            if red_file.cell_value(i, 0) != incidence_angles[n]:
                continue
            elif red_file.cell_value(i, 4) == 0:
                altitude_red.append(90 - red_file.cell_value(i, 2))
                data_red.append(red_file.cell_value(i, 6))
            elif red_file.cell_value(i, 4) == 180:
                altitude_red.append(180 - (90 - red_file.cell_value(i, 2)))
                data_red.append(red_file.cell_value(i, 6))

        # Plot Points
        blue_plot.scatter(np.radians(altitude_blue), data_blue, color=colors[n])
        green_plot.scatter(np.radians(altitude_green), data_green, color=colors[n])
        red_plot.scatter(np.radians(altitude_red), data_red, color=colors[n])

    # Plot Parameters
    blue_plot.set_title('Blue')
    blue_plot.set_thetamin(0)
    blue_plot.set_thetamax(180)
    blue_plot.legend(['Incidence: 0', 'Incidence: 15', 'Incidence: 30', 'Incidence: 45', 'Incidence: 60',
                      'Incidence: 75'])
    green_plot.set_title('Green')
    green_plot.set_thetamin(0)
    green_plot.set_thetamax(180)
    green_plot.legend(['Incidence: 0', 'Incidence: 15', 'Incidence: 30', 'Incidence: 45', 'Incidence: 60',
                       'Incidence: 75'])
    red_plot.set_title('Red')
    red_plot.set_thetamin(0)
    red_plot.set_thetamax(180)
    red_plot.legend(['Incidence: 0', 'Incidence: 15', 'Incidence: 30', 'Incidence: 45', 'Incidence: 60',
                     'Incidence: 75'])
    # show plots
    plt.show()


def average_data(input_data_directory, output_data_directory, snr_directory,
                 latitude_size_degrees, spot_size_mm, azimuth_width_px):
    print('==Averaging Data...==')
    # initialize variables and arrays
    azimuths = [0, 30, 60, 90, 120, 150, 180]
    lines = ["A", "B", "C", "D", "E", "F", "G"]
    aoi_error_values = [
        # incidence 90, 0 from zenith
        np.degrees(np.arctan(((spot_size_mm / 2) / 148))),
        # incidence 75, 15 from zenith
        15 - np.degrees(np.arctan(((np.sin(np.deg2rad(15)) * 148) - (spot_size_mm / 2)) /
                                  (np.cos(np.deg2rad(15)) * 148))),
        # incidence 60, 30 from zenith
        30 - np.degrees(np.arctan(((np.sin(np.deg2rad(30)) * 148) - (spot_size_mm / 2)) /
                                  (np.cos(np.deg2rad(30)) * 148))),
        # incidence 45, 45 from zenith
        45 - np.degrees(np.arctan(((np.sin(np.deg2rad(45)) * 148) - (spot_size_mm / 2)) /
                                  (np.cos(np.deg2rad(45)) * 148))),
        # incidence 30, 60 from zenith
        60 - np.degrees(np.arctan(((np.sin(np.deg2rad(60)) * 148) - (spot_size_mm / 2)) /
                                  (np.cos(np.deg2rad(60)) * 148))),
        # incidence 15, 75 from zenith
        75 - np.degrees(np.arctan(((np.sin(np.deg2rad(75)) * 148) - (spot_size_mm / 2)) /
                                  (np.cos(np.deg2rad(75)) * 148))),
    ]

    # create output file
    wb4 = Workbook()
    output_data_blue = wb4.add_sheet('output_data_blue', cell_overwrite_ok=True)
    wb5 = Workbook()
    output_data_green = wb5.add_sheet('output_data_green', cell_overwrite_ok=True)
    wb6 = Workbook()
    output_data_red = wb6.add_sheet('output_data_red', cell_overwrite_ok=True)

    # Make Title Header
    output_data_blue.write(0, 0, "Blue Data:")
    output_data_green.write(0, 0, "Green Data:")
    output_data_red.write(0, 0, "Red Data:")

    # Make Blue Headers
    output_data_blue.write(1, 0, "i (Angle of Incidence)")
    output_data_blue.write(1, 1, "i % Error")
    output_data_blue.write(1, 2, "e (Altitude)")
    output_data_blue.write(1, 3, "e Error")
    output_data_blue.write(1, 4, "\u03B8 (Azimuth)")
    output_data_blue.write(1, 5, "\u03B8 Error")
    output_data_blue.write(1, 6, "Blue")
    output_data_blue.write(1, 7, "Blue Error")

    # Make Green Headers
    output_data_green.write(1, 0, "i (Angle of Incidence)")
    output_data_green.write(1, 1, "i Error")
    output_data_green.write(1, 2, "e (Altitude)")
    output_data_green.write(1, 3, "e Error")
    output_data_green.write(1, 4, "\u03B8 (Azimuth)")
    output_data_green.write(1, 5, "\u03B8 Error")
    output_data_green.write(1, 6, "Green")
    output_data_green.write(1, 7, "Green Error")

    # Make Red Headers
    output_data_red.write(1, 0, "i (Angle of Incidence)")
    output_data_red.write(1, 1, "i Error")
    output_data_red.write(1, 2, "e (Altitude)")
    output_data_red.write(1, 3, "e Error")
    output_data_red.write(1, 4, "\u03B8 (Azimuth)")
    output_data_red.write(1, 5, "\u03B8 Error")
    output_data_red.write(1, 6, "Red")
    output_data_red.write(1, 7, "Red Error")

    # the range is 0 to 90 so that it stops on 75 using steps of 15
    incidence_index = 0
    for line_index in range(0, 7):
        aoi_index = 0
        for angle_of_incidence in range(0, 90, 15):
            # open data files
            # RAW flux Data
            wb = open_workbook(input_data_directory + '/incidence_' + str(angle_of_incidence) + '_flux_data.xls')
            flux_file = wb.sheet_by_index(0)
            # SNR
            wb1 = open_workbook(snr_directory + '/incidence_' + str(angle_of_incidence) + '_flux_signal_to_noise.xls')
            s_n_file = wb1.sheet_by_index(0)
            # Signal, from SNR Directory
            wb2 = open_workbook(snr_directory + '/incidence_' + str(angle_of_incidence) + '_flux_average.xls')
            signal_file = wb2.sheet_by_index(0)

            # these values are for reading from the raw data files, not for writing to the averaged files
            # Default values are based on Line A
            line = lines[line_index]
            theta_index = 0
            blue_index = 1
            green_index = 2
            red_index = 3
            data_range = a_i_range
            current_line = 'a'
            # use default values for A
            if line == "A" or line == "a":
                pass
            # set B values
            elif line == "B" or line == "b":
                theta_index = 5
                blue_index = 6
                green_index = 7
                red_index = 8
                data_range = b_i_range
                current_line = 'b'
            # set C values
            elif line == "C" or line == "c":
                theta_index = 10
                blue_index = 11
                green_index = 12
                red_index = 13
                data_range = c_i_range
                current_line = 'c'
            # set D values
            elif line == "D" or line == "d":
                theta_index = 15
                blue_index = 16
                green_index = 17
                red_index = 18
                data_range = d_i_range
                current_line = 'd'
            # set E values
            elif line == "E" or line == "e":
                theta_index = 20
                blue_index = 21
                green_index = 22
                red_index = 23
                data_range = e_i_range
                current_line = 'e'
            # set F values
            elif line == "F" or line == "f":
                theta_index = 25
                blue_index = 26
                green_index = 27
                red_index = 28
                data_range = f_i_range
                current_line = 'f'
            # set G values
            elif line == "G" or line == "g":
                theta_index = 30
                blue_index = 31
                green_index = 32
                red_index = 33
                data_range = g_i_range
                current_line = 'g'
            else:
                print('Invalid Line Parameter')
                exit()
            # Get Angle Array
            angle_array = np.zeros(data_range + 1)
            for i in range(0, data_range):
                angle_array[i] = (flux_file.cell_value(i + 2, theta_index))

            altitude_angle = 15
            write_index = 0
            while altitude_angle < 75:
                # skip angular ranges for the positions of the light sources for Line A
                if line == 'A' or line == 'a':
                    if (9.5 - latitude_size_degrees) <= altitude_angle <= 20.5 or \
                            (24.5 - latitude_size_degrees) <= altitude_angle <= 35.5 or \
                            (39.5 - latitude_size_degrees) <= altitude_angle <= 50.5 or \
                            (59.5 - latitude_size_degrees) <= altitude_angle <= 65.5 or \
                            (69.5 - latitude_size_degrees) <= altitude_angle <= 80.5:
                        # iterate
                        altitude_angle += 0.1
                        continue
                    else:
                        pass
                i_range_start_px = [a_i_range, b_i_range, c_i_range, d_i_range, e_i_range, f_i_range, g_i_range]
                # Note: Values in array are in descending order, but indices are in ascending order.
                # So the index_max represents the min angle value, and index_min holds the max angle value.
                index_max = np.abs(angle_array - altitude_angle).argmin() - 1
                index_min = np.abs(angle_array - (altitude_angle + latitude_size_degrees)).argmin()
                i_center = math.ceil(index_max - index_min) + i_range_start_px[line_index] - 2
                azimuth_error_image = cv2.imread(data_folder_directory + "/b_data_0.png")

                # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data
                # folder.
                j = int(math.ceil(
                    ((i_center ** 3) * float(
                        open(data_folder_directory + "/line_" + current_line + "_coefficients.txt").readlines()[0]))
                    + ((i_center ** 2) * float(
                        open(data_folder_directory + "/line_" + current_line + "_coefficients.txt").readlines()[1]))
                    + (i_center * float(
                        open(data_folder_directory + "/line_" + current_line + "_coefficients.txt").readlines()[2]))
                    + float(
                        open(data_folder_directory + "/line_" + current_line + "_coefficients.txt").readlines()[3])))
                # Equations that determine the azimuth error are set up and initialized here, so they can be called when
                # necessary.
                # angular width of the lines, every line is 4 mm wide with an azimuthal width of 1.55 degrees
                line_angular_width = 1.55
                # Width of line in pixels, starts at 1 for middle pixel and then adds up in the next loop to find its
                # total width in pixels.
                line_width_px = 1
                n = 0
                while True:
                    n += 1
                    if azimuth_error_image[i_center][j + n][0] >= 50:
                        line_width_px += 1
                    if azimuth_error_image[i_center][j - n][0] >= 50:
                        line_width_px += 1
                    if azimuth_error_image[i_center][j + n][0] < 50 and azimuth_error_image[i_center][j - n][0] < 50:
                        break

                azimuth_px_dtheta = line_angular_width / line_width_px

                # this line is to help prevent errors involving bad min and max indexes
                if index_max == index_min or index_max - index_min < 0:
                    altitude_angle += latitude_size_degrees
                    continue
                # Blue Flux
                blue_flux = 0
                for i in range(index_min, index_max + 1):
                    blue_flux += flux_file.cell_value(i + 2, blue_index)
                blue_flux = blue_flux / (index_max - index_min)
                output_data_blue.write(incidence_index + write_index + 2, 6, blue_flux)
                # Blue Error
                blue_signal_error = 0
                for i in range(index_min, index_max + 1):
                    blue_signal_error += (signal_file.cell_value(i + 2, blue_index) /
                                          s_n_file.cell_value(i + 2, blue_index))
                blue_signal_error = blue_signal_error / (index_max - index_min)
                output_data_blue.write(incidence_index + write_index + 2, 7, blue_signal_error)
                # Green Flux
                green_flux = 0
                for i in range(index_min, index_max + 1):
                    green_flux += flux_file.cell_value(i + 2, green_index)
                green_flux = green_flux / (index_max - index_min)
                output_data_green.write(incidence_index + write_index + 2, 6, green_flux)
                # Green Error
                green_signal_error = 0
                for i in range(index_min, index_max + 1):
                    green_signal_error += (signal_file.cell_value(i + 2, green_index) /
                                           s_n_file.cell_value(i + 2, green_index))
                green_signal_error = green_signal_error / (index_max - index_min)
                output_data_green.write(incidence_index + write_index + 2, 7, green_signal_error)
                # Red Flux
                red_flux = 0
                for i in range(index_min, index_max + 1):
                    red_flux += flux_file.cell_value(i + 2, red_index)
                red_flux = red_flux / (index_max - index_min)
                output_data_red.write(incidence_index + write_index + 2, 6, red_flux)
                # Red Error
                red_signal_error = 0
                for i in range(index_min, index_max + 1):
                    red_signal_error += (signal_file.cell_value(i + 2, red_index) /
                                         s_n_file.cell_value(i + 2, red_index))
                red_signal_error = red_signal_error / (index_max - index_min)
                output_data_red.write(incidence_index + write_index + 2, 7, red_signal_error)

                # Angle of Incidence
                output_data_blue.write(incidence_index + write_index + 2, 0, angle_of_incidence)
                output_data_green.write(incidence_index + write_index + 2, 0, angle_of_incidence)
                output_data_red.write(incidence_index + write_index + 2, 0, angle_of_incidence)
                # Angle of Incidence Error
                output_data_blue.write(incidence_index + write_index + 2, 1,
                                       aoi_error_values[aoi_index])
                output_data_green.write(incidence_index + write_index + 2, 1,
                                        aoi_error_values[aoi_index])
                output_data_red.write(incidence_index + write_index + 2, 1,
                                      aoi_error_values[aoi_index])
                # Altitude centered between the max and min
                output_data_blue.write(incidence_index + write_index + 2, 2,
                                       90 - ((angle_array[index_max] + angle_array[index_min]) / 2))
                output_data_green.write(incidence_index + write_index + 2, 2,
                                        90 - ((angle_array[index_max] + angle_array[index_min]) / 2))
                output_data_red.write(incidence_index + write_index + 2, 2,
                                      90 - ((angle_array[index_max] + angle_array[index_min]) / 2))
                # Altitude Error
                output_data_blue.write(incidence_index + write_index + 2, 3,
                                       (angle_array[index_min] - angle_array[index_max]) / 2)
                output_data_green.write(incidence_index + write_index + 2, 3,
                                        (angle_array[index_min] - angle_array[index_max]) / 2)
                output_data_red.write(incidence_index + write_index + 2, 3,
                                      (angle_array[index_min] - angle_array[index_max]) / 2)
                # Azimuth
                output_data_blue.write(incidence_index + write_index + 2, 4, azimuths[line_index])
                output_data_green.write(incidence_index + write_index + 2, 4, azimuths[line_index])
                output_data_red.write(incidence_index + write_index + 2, 4, azimuths[line_index])
                # Azimuth Error
                output_data_blue.write(incidence_index + write_index + 2, 5,
                                       azimuth_px_dtheta * ((azimuth_width_px - 1) / 2))
                output_data_green.write(incidence_index + write_index + 2, 5,
                                        azimuth_px_dtheta * ((azimuth_width_px - 1) / 2))
                output_data_red.write(incidence_index + write_index + 2, 5,
                                      azimuth_px_dtheta * ((azimuth_width_px - 1) / 2))
                # iterate
                write_index += 1
                altitude_angle += latitude_size_degrees
            incidence_index += write_index
            aoi_index += 1

    wb4.save(output_data_directory + '/averaged_data_blue.xls')
    wb5.save(output_data_directory + '/averaged_data_green.xls')
    wb6.save(output_data_directory + '/averaged_data_red.xls')
    pd.read_excel(output_data_directory + '/averaged_data_blue.xls').\
        to_csv(output_data_directory + '/averaged_data_blue.csv', index=False)
    pd.read_excel(output_data_directory + '/averaged_data_green.xls'). \
        to_csv(output_data_directory + '/averaged_data_green.csv', index=False)
    pd.read_excel(output_data_directory + '/averaged_data_red.xls'). \
        to_csv(output_data_directory + '/averaged_data_red.csv', index=False)

    print('==Data Averaging Complete==')


def get_background(captures):
    incidence_angles = [0, 15, 30, 45, 60, 75]

    # SET UP CAMERA*****************************************************************************************************
    cv2.getBuildInformation()
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, horizontal_resolution)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, vertical_resolution)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    # SET UP DAC *******************************************************************************************************
    # find connected daq device
    devices = get_daq_device_inventory(InterfaceType.USB)
    # create daq object
    daq_device = DaqDevice(devices[0])
    dio_device = daq_device.get_dio_device()
    daq_device.connect(connection_code=0)
    # get port types
    dio_info = dio_device.get_info()
    port_types = dio_info.get_port_types()

    # Port
    port = port_types[0]

    # set bit value
    on = 1
    off = 0

    # Configure Port
    dio_device.d_config_port(port, DigitalDirection.OUTPUT)

    # turn on finder light and wait for user input
    # LIGHT ON
    # Set bit 0 to on
    dio_device.d_bit_out(port, 0, 1)
    input("Finder Light On, Press Enter To Continue...\n")
    # LIGHT OFF
    # Set bit 0 to off
    dio_device.d_bit_out(port, 0, 0)

    for incidence_index in range(len(incidence_angles)):
        # GATHER DATA***************************************************************************************************
        print('Stacking Images')
        # LIGHTS ON
        # Set bit 0 to on
        dio_device.d_bit_out(port, incidence_index, on)
        # pre-load frame buffer
        for i in range(3):
            ret, frame = cap.read()
        # frame stack
        frame_stack = np.zeros((vertical_resolution, horizontal_resolution, 3))
        # Fast Mode
        if fast_mode:
            cap.set(cv2.CAP_PROP_EXPOSURE, fast_exposure)
            for i in range(captures):
                # TAKE PICTURE
                ret, frame = cap.read()
                frame_stack += frame
                # loop monitor
                print(i)
        # Precision Mode
        elif not fast_mode:
            for i in range(captures):
                # TAKE RED PICTURE
                cap.set(cv2.CAP_PROP_EXPOSURE, r_exposure)
                ret, frame = cap.read()
                frame_stack[:, :, 2] += frame[:, :, 2]
                # TAKE GREEN PICTURE
                cap.set(cv2.CAP_PROP_EXPOSURE, g_exposure)
                ret, frame = cap.read()
                frame_stack[:, :, 1] += frame[:, :, 1]
                # TAKE BLUE PICTURE
                cap.set(cv2.CAP_PROP_EXPOSURE, b_exposure)
                ret, frame = cap.read()
                frame_stack[:, :, 0] += frame[:, :, 0]
                print(i)
        # LIGHTS OFF
        # Set bit 0 to off
        dio_device.d_bit_out(port, incidence_index, off)
        frame_stack = frame_stack / captures

        # DATA GATHER COMPLETE******************************************************************************************
        print('Image Stacking Complete')

        if not exists(data_folder_directory + "/background"):
            os.makedirs(data_folder_directory + "/background")

        # save frames
        cv2.imwrite(data_folder_directory + "/background/incidence_" + str(incidence_angles[incidence_index])
                    + "_background.png", frame_stack)

    # Disconnect Camera
    cap.release()
    cv2.destroyAllWindows()

    print("==Background Measurement Complete==")


def get_reference(captures, azimuth_width_px, material_name):
    incidence_angles = [0, 15, 30, 45, 60, 75]
    reference_data_directory = data_folder_directory + '/reference_library/' + material_name + '_' + str(
        captures) + '_width_' + str(azimuth_width_px)
    # Get Picture with internal function
    data = collect_data(captures)

    # ******************************************************************************************************************
    # GET PHOTON FLUX DATA *********************************************************************************************
    # ******************************************************************************************************************

    # STORE FLUX
    # Create Excel file Workbook
    wb = Workbook()
    spreadsheet = wb.add_sheet('data', cell_overwrite_ok=True)
    spreadsheet.write(0, 0, "A Flux:")
    spreadsheet.write(1, 0, "Theta")
    spreadsheet.write(1, 1, "Blue")
    spreadsheet.write(1, 2, "Green")
    spreadsheet.write(1, 3, "Red")

    spreadsheet.write(0, 5, "B Flux:")
    spreadsheet.write(1, 5, "Theta")
    spreadsheet.write(1, 6, "Blue")
    spreadsheet.write(1, 7, "Green")
    spreadsheet.write(1, 8, "Red")

    spreadsheet.write(0, 10, "C Flux:")
    spreadsheet.write(1, 10, "Theta")
    spreadsheet.write(1, 11, "Blue")
    spreadsheet.write(1, 12, "Green")
    spreadsheet.write(1, 13, "Red")

    spreadsheet.write(0, 15, "D Flux:")
    spreadsheet.write(1, 15, "Theta")
    spreadsheet.write(1, 16, "Blue")
    spreadsheet.write(1, 17, "Green")
    spreadsheet.write(1, 18, "Red")

    spreadsheet.write(0, 20, "E Flux:")
    spreadsheet.write(1, 20, "Theta")
    spreadsheet.write(1, 21, "Blue")
    spreadsheet.write(1, 22, "Green")
    spreadsheet.write(1, 23, "Red")

    spreadsheet.write(0, 25, "F Flux:")
    spreadsheet.write(1, 25, "Theta")
    spreadsheet.write(1, 26, "Blue")
    spreadsheet.write(1, 27, "Green")
    spreadsheet.write(1, 28, "Red")

    spreadsheet.write(0, 30, "G Flux:")
    spreadsheet.write(1, 30, "Theta")
    spreadsheet.write(1, 31, "Blue")
    spreadsheet.write(1, 32, "Green")
    spreadsheet.write(1, 33, "Red")

    for incidence_index in range(len(incidence_angles)):
        # initialize color channel variable stacks as arrays of zeros with the resolution of the camera image HARDCODED
        r = data[incidence_index, :, :, 2]
        g = data[incidence_index, :, :, 1]
        b = data[incidence_index, :, :, 0]

        r[r < 0] = 0
        g[g < 0] = 0
        b[b < 0] = 0

        # save split images
        cv2.imwrite(data_folder_directory + "/r_data_" + str(incidence_angles[incidence_index]) + ".png", r)
        cv2.imwrite(data_folder_directory + "/g_data_" + str(incidence_angles[incidence_index]) + ".png", g)
        cv2.imwrite(data_folder_directory + "/b_data_" + str(incidence_angles[incidence_index]) + ".png", b)

        # A FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_a = a_i_range_min
        a_flux = np.zeros((a_i_range_max - a_i_range_min + 10, 4))
        for i in range(theta_px_a, a_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_a_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_a
            # Fill Flux Array
            # angle calculated using polynomial equation
            a_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_a_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_a_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_a_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_a_angle_coefficients.txt").readlines()[3])
            # blue flux
            a_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            a_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            a_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 0, a_flux[n][0])
            spreadsheet.write(n + 2, 1, a_flux[n][1])
            spreadsheet.write(n + 2, 2, a_flux[n][2])
            spreadsheet.write(n + 2, 3, a_flux[n][3])

        # B FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_b = b_i_range_min
        b_flux = np.zeros((b_i_range_max - b_i_range_min + 10, 4))
        for i in range(theta_px_b, b_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_b_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_b
            # Fill Flux Array
            # angle calculated using polynomial equation
            b_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_b_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_b_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_b_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_b_angle_coefficients.txt").readlines()[3])
            # blue flux
            b_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            b_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            b_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 5, b_flux[n][0])
            spreadsheet.write(n + 2, 6, b_flux[n][1])
            spreadsheet.write(n + 2, 7, b_flux[n][2])
            spreadsheet.write(n + 2, 8, b_flux[n][3])

        # C FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_c = c_i_range_min
        c_flux = np.zeros((c_i_range_max - c_i_range_min + 10, 4))
        for i in range(theta_px_c, c_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_c_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_c
            # Fill Flux Array
            # angle calculated using polynomial equation
            c_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_c_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_c_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_c_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_c_angle_coefficients.txt").readlines()[3])
            # blue flux
            c_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            c_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            c_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 10, c_flux[n][0])
            spreadsheet.write(n + 2, 11, c_flux[n][1])
            spreadsheet.write(n + 2, 12, c_flux[n][2])
            spreadsheet.write(n + 2, 13, c_flux[n][3])

        # D FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_d = d_i_range_min
        d_flux = np.zeros((d_i_range_max - d_i_range_min + 10, 4))
        for i in range(theta_px_d, d_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_d_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_d
            # Fill Flux Array
            # angle calculated using polynomial equation
            d_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_d_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_d_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_d_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_d_angle_coefficients.txt").readlines()[3])
            # blue flux
            d_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            d_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            d_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 15, d_flux[n][0])
            spreadsheet.write(n + 2, 16, d_flux[n][1])
            spreadsheet.write(n + 2, 17, d_flux[n][2])
            spreadsheet.write(n + 2, 18, d_flux[n][3])

        # E FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_e = e_i_range_min
        e_flux = np.zeros((e_i_range_max - e_i_range_min + 10, 4))
        for i in range(theta_px_e, e_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_e_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_e
            # Fill Flux Array
            # angle calculated using polynomial equation
            e_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_e_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_e_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_e_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_e_angle_coefficients.txt").readlines()[3])
            # blue flux
            e_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            e_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            e_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 20, e_flux[n][0])
            spreadsheet.write(n + 2, 21, e_flux[n][1])
            spreadsheet.write(n + 2, 22, e_flux[n][2])
            spreadsheet.write(n + 2, 23, e_flux[n][3])

        # F FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_f = f_i_range_min
        f_flux = np.zeros((f_i_range_max - f_i_range_min + 10, 4))
        for i in range(theta_px_f, f_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_f_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_f
            # Fill Flux Array
            # angle calculated using polynomial equation
            f_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_f_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_f_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_f_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_f_angle_coefficients.txt").readlines()[3])
            # blue flux
            f_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            f_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            f_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 25, f_flux[n][0])
            spreadsheet.write(n + 2, 26, f_flux[n][1])
            spreadsheet.write(n + 2, 27, f_flux[n][2])
            spreadsheet.write(n + 2, 28, f_flux[n][3])

        # G FLUX********************************************************************************************************
        # define left line Flux Storage right_flux[[theta, b, g, r]]
        # storage array is oversized to prevent errors
        theta_px_g = g_i_range_min
        g_flux = np.zeros((g_i_range_max - g_i_range_min + 10, 4))
        for i in range(theta_px_g, g_i_range_max):
            # Find line center using a 3rd order polynomial with coefficients from relevant .txt files in data folder.
            j = int(math.ceil(((i ** 3) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[0]))
                              + ((i ** 2) * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[1]))
                              + (i * float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[2]))
                              + float(open(data_folder_directory + "/line_g_coefficients.txt").readlines()[3])))
            # n is used to start filling the array at array[0][] instead of array[i][]
            # this is needed so that the data lines up at the same starting angle
            n = i - theta_px_g
            # Fill Flux Array
            # angle calculated using polynomial equation
            g_flux[n][0] = ((i ** 3) * float(open(data_folder_directory
                                                  + "/line_g_angle_coefficients.txt").readlines()[0])) \
                           + ((i ** 2) * float(open(data_folder_directory
                                                    + "/line_g_angle_coefficients.txt").readlines()[1])) \
                           + (i * float(open(data_folder_directory + "/line_g_angle_coefficients.txt").readlines()[2])) \
                           + float(open(data_folder_directory + "/line_g_angle_coefficients.txt").readlines()[3])
            # blue flux
            g_flux[n][1] = sum(b[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # green flux
            g_flux[n][2] = sum(g[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])
            # red flux
            g_flux[n][3] = sum(r[i][j - math.floor(azimuth_width_px / 2): j + math.floor(azimuth_width_px / 2) + 1])

            # write to Excel file
            spreadsheet.write(n + 2, 30, g_flux[n][0])
            spreadsheet.write(n + 2, 31, g_flux[n][1])
            spreadsheet.write(n + 2, 32, g_flux[n][2])
            spreadsheet.write(n + 2, 33, g_flux[n][3])

        # Check if destination directory exists, if not, create it.
        if not exists(reference_data_directory):
            os.makedirs(reference_data_directory)

        # save excel sheet
        wb.save(reference_data_directory + "/incidence_" + str(incidence_angles[incidence_index]) + "_flux_data.xls")

        # ensure flux data exists before finishing
        while not exists(reference_data_directory + "/incidence_" + str(incidence_angles[incidence_index])
                         + "_flux_data.xls"):
            continue

    # END***************************************************************************************************************
    # Current Operating Prototype
    print('==Reference Measurement Complete==')
