import goniometer
from colorama import Fore

# CONFIGURE REFERENCE
########################################################################################################################
# recommended 10
captures = None
material_name = None
# recommend 5
azimuth_width_px = 5
########################################################################################################################

# check that data directory in goniometer library is set correctly
try:
    if goniometer.data_folder_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
    exit()

# Get Reference
goniometer.get_reference(captures, azimuth_width_px, material_name)
