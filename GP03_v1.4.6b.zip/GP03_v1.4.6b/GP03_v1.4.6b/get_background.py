import goniometer
from colorama import Fore

# CONFIGURE BACKGROUND
########################################################################################################################
# recommend 10
captures = None
########################################################################################################################

# check that data directory in goniometer library is set correctly
try:
    if goniometer.data_folder_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
    exit()

# get_background
goniometer.get_background(captures)
