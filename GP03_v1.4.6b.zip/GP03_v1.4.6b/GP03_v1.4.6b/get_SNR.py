import goniometer
from colorama import Fore

# CONFIGURE SNR
########################################################################################################################
# recommend 10
captures = None
# recommend 5
width = None
# recommend 100
sn_stack_num = None
material_name = None
########################################################################################################################

# check that data directory in goniometer library is set correctly
try:
    if goniometer.data_folder_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder In 'goniometer' Library")
    exit()

# get_SNR
goniometer.flux_signal_to_noise(captures, width, sn_stack_num, material_name)
