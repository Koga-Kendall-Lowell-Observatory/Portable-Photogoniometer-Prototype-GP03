import goniometer
from colorama import Fore

# CONFIGURE ANGULAR POSITIONING CALIBRATION
########################################################################################################################
led_bit = None
# recommend 10
captures = None
########################################################################################################################

# check that user has set the directory
try:
    if goniometer.data_folder_directory is not None:
        pass
    else:
        raise TypeError
except TypeError:
    print(Fore.RED + "TypeError: Missing Data Folder Directory")
    exit()

# calibrate the line equations
goniometer.calibrate_angles()
